package Mod�les;

import java.sql.Date;

public class Demandesupp {

	int num;
	String titre;
	Date date;
	String users;
	String motif;
	String etat;
	
	public Demandesupp(int a,String b,Date c,String d,String e,String f){
		this.num=a;
		this.titre=b;
		this.date=c;
		this.users=d;
		this.motif=e;
		this.etat=f;
	}

	public String getMotif() {
		return motif;
	}

	public void setMotif(String motif) {
		this.motif = motif;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getUsers() {
		return users;
	}

	public void setUsers(String users) {
		this.users = users;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}
	
}
