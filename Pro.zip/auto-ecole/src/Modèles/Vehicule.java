package Mod�les;

import java.sql.Date;

public class Vehicule {
	int num;
	String matricule;
	String nom;
	String marque;
	String type;
	String etat;
	Date entret;
	
	public Vehicule(int i, String string, String string2, String string3, String string4, String string5, Date date) {
		// TODO Auto-generated constructor stub
		this.num=i;
		this.matricule=string;
		this.nom=string2;
		this.marque=string3;
		this.type=string4;
		this.etat=string5;
		this.entret=date;
	}


	public String getEtat() {
		return etat;
	}


	public void setEtat(String etat) {
		this.etat = etat;
	}


	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


	public Date getEntret() {
		return entret;
	}


	public void setEntret(Date entret) {
		this.entret = entret;
	}

	
	
}
