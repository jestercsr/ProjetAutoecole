package Mod�les;

import java.sql.Date;
import java.time.LocalDate;

public class Evenements {
	int num;
	String nom_eve;
	Date date_eve;
	String heure_deb;
	String heure_fin;
	String nom_user;
	String nom_emp;
	

	public Evenements(int int1, String string, Date date, String string3, String string4, String string5,
			String string6) {
		// TODO Auto-generated constructor stub
		this.num=int1;
		this.nom_eve=string;
		this.date_eve=date;
		this.heure_deb=string3;
		this.heure_fin=string4;
		this.nom_user=string5;
		this.nom_emp=string6;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getNom_eve() {
		return nom_eve;
	}

	public void setNom_eve(String nom_eve) {
		this.nom_eve = nom_eve;
	}

	public Date getDate_eve() {
		return date_eve;
	}

	public void setDate_eve(Date date_eve) {
		this.date_eve = date_eve;
	}

	public String getHeure_deb() {
		return heure_deb;
	}

	public void setHeure_deb(String heure_deb) {
		this.heure_deb = heure_deb;
	}

	public String getHeure_fin() {
		return heure_fin;
	}

	public void setHeure_fin(String heure_fin) {
		this.heure_fin = heure_fin;
	}

	public String getNom_user() {
		return nom_user;
	}

	public void setNom_user(String nom_user) {
		this.nom_user = nom_user;
	}

	public String getNom_emp() {
		return nom_emp;
	}

	public void setNom_emp(String nom_emp) {
		this.nom_emp = nom_emp;
	}
	

}
