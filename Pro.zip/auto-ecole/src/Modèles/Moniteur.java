package Mod�les;

public class Moniteur {
	
	String id_emp;
	String nom_emp;
	String mail_emp;
	String num_emp;
	String id_user;
	
	public Moniteur(String a, String b,String c,String d,String e){
		this.id_emp=a;
		this.nom_emp=b;
		this.mail_emp=c;
		this.num_emp=d;
		this.id_user=e;
	}

	public String getId_emp() {
		return id_emp;
	}

	public void setId_emp(String id_emp) {
		this.id_emp = id_emp;
	}

	public String getNom_emp() {
		return nom_emp;
	}

	public void setNom_emp(String nom_emp) {
		this.nom_emp = nom_emp;
	}

	public String getMail_emp() {
		return mail_emp;
	}

	public void setMail_emp(String prenom_emp) {
		this.mail_emp = prenom_emp;
	}

	public String getNum_emp() {
		return num_emp;
	}

	public void setNum_emp(String num_emp) {
		this.num_emp = num_emp;
	}

	public String getId_user() {
		return id_user;
	}

	public void setId_user(String id_user) {
		this.id_user = id_user;
	}
	

}
