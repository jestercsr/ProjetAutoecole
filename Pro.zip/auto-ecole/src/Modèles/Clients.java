package Mod�les;

public class Clients {
	String id_user;
	String nom_user;
	String mail_user;
	String num_user;
	float mont_pay�;
	String permis;

	public Clients(String int1, String string, String string3, String string4,float a,String permis) {
		// TODO Auto-generated constructor stub
		this.id_user=int1;
		this.nom_user=string;
		this.mail_user=string3;
		this.num_user=string4;
		this.mont_pay�=a;
		this.permis=permis;
	}

	public String getPermis() {
		return permis;
	}

	public void setPermis(String permis) {
		this.permis = permis;
	}

	public float getMont_pay�() {
		return mont_pay�;
	}

	public void setMont_pay�(float mont_pay�) {
		this.mont_pay� = mont_pay�;
	}

	public String getId_user() {
		return id_user;
	}

	public void setId_user(String id_user) {
		this.id_user = id_user;
	}

	public String getNom_user() {
		return nom_user;
	}

	public void setNom_user(String nom_user) {
		this.nom_user = nom_user;
	}

	public String getMail_user() {
		return mail_user;
	}

	public void setMail_user(String mail_user) {
		this.mail_user = mail_user;
	}

	public String getNum_user() {
		return num_user;
	}

	public void setNum_user(String num_user) {
		this.num_user = num_user;
	}

	

	

}
