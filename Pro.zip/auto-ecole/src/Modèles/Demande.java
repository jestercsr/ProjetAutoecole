package Mod�les;

import java.sql.Date;

public class Demande {
	int num;
	String titre;
	Date date;
	String heure;
	String users;
	String etat;
	
	public Demande(int a,String b,Date c,String d,String e,String f){
		this.num=a;
		this.titre=b;
		this.date=c;
		this.heure=d;
		this.users=e;
		this.etat=f;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getHeure() {
		return heure;
	}

	public void setHeure(String heure) {
		this.heure = heure;
	}

	public String getUsers() {
		return users;
	}

	public void setUsers(String users) {
		this.users = users;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}
	
}
