package Interface;

import javafx.collections.ObservableList;

public interface Liste1 {
	public ObservableList<String> afficher1();
}
