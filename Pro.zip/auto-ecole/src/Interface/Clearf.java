package Interface;

public interface Clearf {
	public void clearFields();
}
