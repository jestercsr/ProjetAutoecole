package Interface;

import javafx.collections.ObservableList;

public interface Liste {
	public ObservableList<String> afficher();
}
