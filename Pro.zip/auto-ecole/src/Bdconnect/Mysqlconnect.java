package Bdconnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import Mod�les.Clients;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Mysqlconnect {
	
	Connection con=null;
	
	public static Connection ConnectDb() {
		//Connection � la base de donn�es//
		String BDD = "auto-ecole";
		String url = "jdbc:mysql://localhost:3306/" + BDD;
		String user = "root";
		String passwd = "";
		// L'essaie de connexion � votre base de don�es
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, passwd);
			//JOptionPane.showMessageDialog(null, "Connection �tablie");
		    	 	return con;
		} catch (Exception e){
		     e.printStackTrace();
		    // JOptionPane.showMessageDialog(null, "Connection �chou�e");
		        return null;
		                }
		
	}
	
	

}
