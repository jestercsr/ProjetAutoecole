package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Validationdemandecontroller implements Initializable{
	
	 @FXML
	    private Label date;

	    @FXML
	    private Label heure;

	    @FXML
	    private Button rejet;

	    @FXML
	    private Label titre;
	    
	    @FXML
	    private AnchorPane mas;

	    @FXML
	    private Label user;

	    @FXML
	    private Button validation;
	    public static String s;
	    public static String a;
	   

	    @FXML
	    void rejeter(MouseEvent event) throws SQLException, IOException {

	    	try {
     			Connection con=Mysqlconnect.ConnectDb();
	        		String[] NPTab1 = user.getText().split(" ");
	 				PreparedStatement st=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\" ");
 	 	 			ResultSet res=st.executeQuery(); 
 	 	 		  while(res.next()) {
 	 	 		  s=res.getString("mail_user");
 	 	 		  a=titre.getText();
 	 	 		  }}catch(Exception e) {
 	 	 			  e.printStackTrace();
 	 	 		  }
	    	 Parent root = FXMLLoader.load(getClass().getResource("/admininterfaces/DemandeRecap.fxml"));
	            Scene scene = new Scene(root);
	            Stage appStage = (Stage) mas.getScene().getWindow();
	            appStage.setScene(scene);
	            appStage.show();
 			}

	    @FXML
	    void valider(MouseEvent event) throws SQLException {
	    	Connection  connection = Mysqlconnect.ConnectDb();
            
	    	String[] NPTab = user.getText().split(" ");
				PreparedStatement st1=connection.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab[1]+"\" AND nom_user = \""+NPTab[0]+"\" ");
			
 			ResultSet res1=st1.executeQuery(); 
 			while(res1.next()) {
 				//s=res1.getString("mail_user");
     		PreparedStatement st2=connection.prepareStatement("UPDATE demandeclient set etat='Valid�', statut='Non vu' WHERE id_user='"+res1.getString("id_user")+"' and titre='"+titre.getText()+"'");
     		st2.execute();
     		//st3.execute();
     		try {
     			Connection con=Mysqlconnect.ConnectDb();
	        		String[] NPTab1 = user.getText().split(" ");
	 				PreparedStatement st=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\" ");
 	 	 			ResultSet res=st.executeQuery(); 
 	 	 		  while(res.next()) {
	 	 					char c=heure.getText().charAt(1);
	 	 	 	 	 		int a=c+2;
	 	 	 	 	 		String b=Character.toString(a);
	 	 	 	 	 		String heuref=heure.getText().charAt(0)+b+heure.getText().charAt(2)+heure.getText().charAt(3)+heure.getText().charAt(4);
							con = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
							PreparedStatement stmt = con.prepareStatement("INSERT INTO seances ( nom_eve, date_eve, heure_debut, heure_fin, id_user,id_emp) VALUES (?,?,?,?,?,?)");
							stmt.setString(1, titre.getText());
							stmt.setString(2, date.getText());
							stmt.setString(3, heure.getText());
							stmt.setString(4, heuref);
							stmt.setInt(5, res.getInt("id_user"));
							stmt.setInt(6, res.getInt("tuteur"));
							
							stmt.executeUpdate();
							
							Alert alert = new Alert(Alert.AlertType.ERROR);
							alert.setHeaderText(null);
							alert.setContentText("Cet evenement a �t� ajout� � votre planning");
							alert.showAndWait();
							  Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
						        stage.close();
 	 				}
 	 			}catch (Exception ex) {
				
				ex.printStackTrace();
		
 			} 
 	 			}
	 	 			
     		//JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
 			}
	    
	    
	    void setData(String a,String b,String c,String d) {
	    	titre.setText(a);
	    	user.setText(b);
	    	date.setText(c);
	    	heure.setText(d);
	    }
	    String recuperer() {
	    	Connection  connection = Mysqlconnect.ConnectDb();
	        String n = null;
	    	String[] NPTab = user.getText().split(" ");
				PreparedStatement st1;
				try {
					st1 = connection.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab[1]+"\" AND nom_user = \""+NPTab[0]+"\" ");
					ResultSet res1=st1.executeQuery(); 
					while(res1.next()) {
						n=res1.getString("mail_user");}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return n;
	    }
	    String recuperer1() {
			return titre.getText();
	    	
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
