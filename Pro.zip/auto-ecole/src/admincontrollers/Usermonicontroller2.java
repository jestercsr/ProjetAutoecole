package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;

public class Usermonicontroller2 implements Initializable,Liste{
	ObservableList<String> list;
	@FXML
    private ChoiceBox<String> choixuser;

    @FXML
    void annuler(MouseEvent event) {

    }

    @FXML
    void choixoption(MouseEvent event) {
    	list=afficher();
    	choixuser.setItems(list);
    }

    @FXML
    void mas(MouseEvent event) {
    	
    }
   
    
    
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		try {
				
				
    			PreparedStatement st1=con.prepareStatement("SELECT * FROM utilisateurs WHERE tuteur==0");
    			
    			ResultSet res1=st1.executeQuery(); 
    			while(res1.next()) {
    				
						list.add(res1.getString("nom_user")+" "+res1.getString("prenom_user"));
    					
    			}
    			
    		}catch(Exception e) {
    			System.out.println();
    		}
		return list;
	}

}
