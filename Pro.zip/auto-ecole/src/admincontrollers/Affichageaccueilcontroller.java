package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Interface.Liste1;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

public class Affichageaccueilcontroller implements Initializable,Liste,Liste1{
	
	  @FXML
	    private ListView<String> currentinscrip;

	    @FXML
	    private ListView<String> programmejour;
	    @FXML
	    private ListView<String> currentdemande;
	    
	    	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		afficher();
		afficher1();
		afficher2();
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
	try {
			PreparedStatement st=con.prepareStatement("SELECT * FROM seances WHERE date_eve=DATE(NOW()) ORDER BY seances.heure_debut ASC");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				listprog.add(res.getString("heure_debut")+"-"+ 
						res.getString("heure_fin")+" : "+res.getString("nom_eve")
							+" suivi par M. "+
							res.getString("id_user")+" sous la tutelle de M. "+
							res.getString("id_emp"));
				}
			programmejour.getItems().addAll(listprog);
		}catch(Exception e) {
			System.out.println();
		}
	return listprog;
	}
	
	@Override
	public ObservableList<String> afficher1() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
	try {
			PreparedStatement st=con.prepareStatement("SELECT * FROM utilisateurs WHERE date_insc=DATE(NOW())");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				listprog.add("Le client "+res.getString("nom_user")+" "+ 
						res.getString("prenom_user")+" s'est inscrit sur votre plateforme aujourd'hui ");
				}
			currentinscrip.getItems().addAll(listprog);
		}catch(Exception e) {
			System.out.println();
		}
	return listprog;
	}
	
	public ObservableList<String> afficher2() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
	try {
		PreparedStatement st1=con.prepareStatement("SELECT * FROM demandeclient where date_dem=DATE(NOW()) and etat='En attente'");
		ResultSet res1=st1.executeQuery(); 
		PreparedStatement st2=con.prepareStatement("SELECT * FROM demandesupp date=DATE(NOW()) and etat='En attente'");
		ResultSet res2=st2.executeQuery(); 
		if(res1.next()==true || res2.next()==true) {
			
			PreparedStatement st=con.prepareStatement("SELECT * FROM utilisateurs WHERE id_user='"+res1.getString("id_user")+"' ");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				listprog.add("Le client "+res.getString("nom_user")+" "+ 
						res.getString("prenom_user")+" a formul� une demande ");
				}
			PreparedStatement st3=con.prepareStatement("SELECT * FROM utilisateurs WHERE id_user='"+res2.getString("id_user")+"' ");
			ResultSet res3=st3.executeQuery(); 
			while(res.next()) {
				listprog.add("Le client "+res3.getString("nom_user")+" "+ 
						res3.getString("prenom_user")+" a formul� une demande ");
				}
			currentdemande.getItems().addAll(listprog);
		}
		}catch(Exception e) {
			System.out.println();
		}
	return listprog;
	}

}
