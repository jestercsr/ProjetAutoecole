package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class Usermonicontroller implements Initializable,Liste{
	ObservableList<String> list;
	Connection con;
	@FXML
    private ChoiceBox<String> choixuser;

    @FXML
    void annuler(MouseEvent event) {

    }

    @FXML
    void choixoption(MouseEvent event) {
    	list=afficher();
    	choixuser.setItems(list);
    }

    @FXML
    void mas(MouseEvent event) throws SQLException {
    	
    		con=Mysqlconnect.ConnectDb();
    		 FXMLLoader loader = new FXMLLoader ();
    		 loader.setLocation(getClass().getResource("/admininterfaces/Moniteurmodif.fxml"));
    		 try {
                 loader.load();
             } catch (IOException ex) {
                 //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
             }
    		// Moniteurmodifcontroller modif=loader.getController();
    		 con=Mysqlconnect.ConnectDb();
    		String val4=Moniteurmodifcontroller.result;
    		System.out.println(val4);
    		String[] NPTab = val4.split(" ");
    		
    		 PreparedStatement st1=con.prepareStatement("select * from moniteurs where prenom_emp = \""+NPTab[1]+"\" AND nom_emp = \""+NPTab[0]+"\" ");
	 			ResultSet res1=st1.executeQuery(); 
	 			
	 			String[] NPTab1 = choixuser.getValue().split(" ");
			 				PreparedStatement st2=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\" ");
				 			ResultSet res2=st2.executeQuery(); 
				 			if(res1.next() && res2.next()) {
				 				
				 			
	     		PreparedStatement st3=con.prepareStatement("UPDATE utilisateurs set tuteur='"+res1.getInt("id_emp")+"' WHERE id_user='"+res2.getInt("id_user")+"'");
	     		st3.execute();
	     		System.out.println(res2.getString("id_user"));
	     		System.out.println(res1.getString("id_emp"));
	     		System.out.println(choixuser.getValue());
	     		
	     		
	 			JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
	 			}
				 			}
			 			
    	
    		
    	
    
   
    
    
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		con=Mysqlconnect.ConnectDb();
  		 FXMLLoader loader = new FXMLLoader ();
  		 loader.setLocation(getClass().getResource("/admininterfaces/Moniteurmodif.fxml"));
  		 try {
               loader.load();
           } catch (IOException ex) {
               //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
           }
  		// Moniteurmodifcontroller modif=loader.getController();
  		 con=Mysqlconnect.ConnectDb();
  		String val4=Moniteurmodifcontroller.result;
		try {
			
   		System.out.println(val4);
   		String[] NPTab = val4.split(" ");
   		
   		 PreparedStatement st=con.prepareStatement("select * from moniteurs where prenom_emp = \""+NPTab[1]+"\" AND nom_emp = \""+NPTab[0]+"\" ");
	 			
    			
    			ResultSet res=st.executeQuery(); 
    			while(res.next()) {
    				try {
    					PreparedStatement st1=con.prepareStatement("SELECT * FROM utilisateurs WHERE tuteur!=0 and tuteur!='"+res.getInt("id_emp")+"' and etat_compte!='Supprim�'");
    	    			
    	    			ResultSet res1=st1.executeQuery(); 
    	    			while(res1.next()) {
    	    				
    							list.add(res1.getString("nom_user")+" "+res1.getString("prenom_user"));
    	    					
    	    			}
    				}catch(Exception e) {
    					e.printStackTrace();
    				}
    			
    			}
    		}catch(Exception e) {
    			e.printStackTrace();
    		}
		return list;
	}

}
