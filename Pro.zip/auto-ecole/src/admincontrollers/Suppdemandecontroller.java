package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;

public class Suppdemandecontroller implements Initializable{
	
	  @FXML
	    private Label date;

	    @FXML
	    private TextArea motif;

	    @FXML
	    private Button rejet;

	    @FXML
	    private Label titre;

	    @FXML
	    private Label user;

	    @FXML
	    private Button validation;

	    @FXML
	    void rejeter(MouseEvent event) throws SQLException {
	    	Connection  connection = Mysqlconnect.ConnectDb();
	    	PreparedStatement st1=connection.prepareStatement("select * from utilisateurs where nom_user+\' \'+prenom_user='"+user.getText()+"'");
 			ResultSet res1=st1.executeQuery(); 
 			while(res1.next()) {
     		
     		String sql="UPDATE demandesupp set etat='Rejeter' WHERE id_user='"+res1.getString("id_user")+"'";
     		//String sql1="Insert into moniteurs ('"+res.getInt("id_emp")+"','"+res.getString("nom_emp")+"','"+res.getString("prenom_emp")+"','"+res.getString("mail_emp")+"','"+res.getString("num_emp")+"','"+res.getString("code_postal")+"','"+res.getString("nom_ville")+"','"+res.getString("complement_adress")+"','"+res.getString("mot_passe")+"','"+res1.getInt("id_user")+"'";
     		PreparedStatement st2=connection.prepareStatement(sql);
     		st2.execute();
     		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
 			}
	    }

	    @FXML
	    void valider(MouseEvent event) {
	    	try {
	               Connection  connection = Mysqlconnect.ConnectDb();
	                PreparedStatement st1=connection.prepareStatement("select * from utilisateurs where nom_user+\' \'+prenom_user='"+user.getText()+"'");
		 			ResultSet res1=st1.executeQuery(); 
		 			while(res1.next()) {
		     		//String sql1="Insert into moniteurs ('"+res.getInt("id_emp")+"','"+res.getString("nom_emp")+"','"+res.getString("prenom_emp")+"','"+res.getString("mail_emp")+"','"+res.getString("num_emp")+"','"+res.getString("code_postal")+"','"+res.getString("nom_ville")+"','"+res.getString("complement_adress")+"','"+res.getString("mot_passe")+"','"+res1.getInt("id_user")+"'";
		     		PreparedStatement st2=connection.prepareStatement("UPDATE demandesupp set etat='Valid�' WHERE id_user='"+res1.getString("id_user")+"'");
		     		PreparedStatement st3=connection.prepareStatement("DELETE from seances WHERE id_user='"+res1.getString("id_user")+"'");
		     		st2.execute();
		     		st3.execute();
		     		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
		 			}
	                
	            } catch (SQLException ex) {
	             //   Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
	            	ex.printStackTrace();
	            }
	    }
	    void setData(String a,String b,String c,String d) {
	    	titre.setText(a);
	    	user.setText(b);
	    	date.setText(c);
	    	motif.setText(d);
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
