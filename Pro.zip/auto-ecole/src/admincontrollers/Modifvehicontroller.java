package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Interface.Liste1;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Modifvehicontroller implements Initializable,Liste,Liste1{
		ObservableList<String> liste;
		ObservableList<String> liste1;
		Connection con=null;
	    PreparedStatement ps=null;
	    ResultSet res=null;
	 @FXML
	    private ChoiceBox<String> etat;
	 
	 	@FXML
	    private AnchorPane suite;

	    @FXML
	    private ChoiceBox<String> type;

	    @FXML
	    private DatePicker entre;
	    
	    @FXML
	    private TextField marque;

	    @FXML
	    private TextField matricule;

	    @FXML
	    private TextField nom;
	    
	   // private boolean update;
	    

	    @FXML
	    void annuler(MouseEvent event) throws IOException {
	    	
	    }

	    @FXML
	    void valider(MouseEvent event) {
	    	try {
	    	con=Mysqlconnect.ConnectDb();
    		String val1=nom.getText();
    		String val2=matricule.getText();
    		String val3=marque.getText();
    		String val4=type.getValue();
    		String val5=etat.getValue();
    		LocalDate val6=entre.getValue();
    	        	String sql="Update vehicules set num_matri='"+val2+"',nom_vehi='"+val1+"',marque_vehic='"+val3+"',type_vehi='"+val4+"',etat_vehi='"+val5+"',date_entre='"+val6+"' where num_matri='"+val2+"'";
    	    		PreparedStatement st=con.prepareStatement(sql);
    	    		st.execute();
    	    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
    	    	}catch(Exception e) {
    	    	
    	        }
    		
    		
	    }
	    void monchoix(ActionEvent event) {
	    	if(etat.getValue()=="Neuf") {
	    		entre.setValue(java.time.LocalDate.now());
	    	}
	    }
	    @FXML
	    void choixetat(MouseEvent event) {
	    	liste1=afficher1();
	    	etat.setItems(liste1);
	    }
	    

	    @FXML
	    void choixtype(MouseEvent event) {
	    	liste=afficher();
	    	type.setItems(liste);
	    }
	    void setTextField(String a, String b, String c,String d,String e, LocalDate string) {

	        nom.setText(a);
	        matricule.setText(b);
	        marque.setText(c);
	        type.setValue(d);
	        etat.setValue(e);
	       entre.setValue(string);

	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Automatique","Manuelle"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

	@Override
	public ObservableList<String> afficher1() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"En cours de r�paration","Endommag�e"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}
	
	 
}
