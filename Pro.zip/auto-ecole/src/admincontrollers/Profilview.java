package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class Profilview implements Initializable{
	
	 @FXML
	    private Label adresse;

	    @FXML
	    private Label age;

	    @FXML
	    private Label mail;

	    @FXML
	    private Label nom;

	    @FXML
	    private Label permis;

	    @FXML
	    private ProgressBar progress;

	    @FXML
	    private Label tel;
	    
	    void setData(String a,String b,String c,String d,String e,String f) {
	    	nom.setText(a);
	    	age.setText(b);
	    	mail.setText(c);
	    	tel.setText(d);
	    	adresse.setText(e);
	    	permis.setText(f);
	    }
	    @FXML 
	    void progres() {
	    	try {
				Connection con=Mysqlconnect.ConnectDb();
				//String[] NPTab = nom.getText().split(" ");
				//Clients voit = inscritsview.getSelectionModel().getSelectedItem();
	            FXMLLoader loader = new FXMLLoader ();
	            loader.setLocation(getClass().getResource("/admininterfaces/Users.fxml"));
	            try {
	                loader.load();
	            } catch (IOException ex) {
	                //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
	            }
				PreparedStatement st1=con.prepareStatement("select * from utilisateurs where mail_user='"+Userscontroller.m+"'" );
				ResultSet res1=st1.executeQuery(); 
	 			while(res1.next()) {
	 				//System.out.println(res1.getInt("id_user")+"n");
	     		PreparedStatement st2=con.prepareStatement("select * from evolution where id_user='"+res1.getInt("id_user")+"' ");
	     		ResultSet res2=st2.executeQuery();
	     	while(res2.next()) {
	     			
	     			System.out.println(res2.getInt("id_user"));
	     			if(res2.getInt("theorie")==0 && res2.getInt("pratique")==0) {
	     				progress.setProgress(0);
	     			}
	     			if(res2.getInt("theorie")==1 && res2.getInt("pratique")==0) {
	     				progress.setProgress(0.5);
	     			}
	     			if(res2.getInt("theorie")==0 && res2.getInt("pratique")==1) {
	     				progress.setProgress(0.5);
	     			}
	     			if(res2.getInt("theorie")==1 && res2.getInt("pratique")==1) {
	     				progress.setProgress(1);
	     			}
	     		}
	 			}
			}catch(Exception e) {
				e.printStackTrace();
			}
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
	progres();
		//System.out.println(mail.getText());
	}

}
