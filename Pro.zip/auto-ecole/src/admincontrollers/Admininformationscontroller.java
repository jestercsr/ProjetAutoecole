package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Window;

public class Admininformationscontroller implements Initializable{

    @FXML
    private TextField code_postal;

    @FXML
    private TextField comp_adress;

    @FXML
    private TextField email;

    @FXML
    private TextField nom;

    @FXML
    private TextField nom_rue;

    @FXML
    private TextField nom_ville;

    @FXML
    private TextField num;

    @FXML
    private TextField num_rue;

    @FXML
    private TextField prenom;
    
    @FXML
    private Button accepter;


    @FXML
    void quitter(MouseEvent event) {

    }
    public static final Pattern valid_email =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    public static boolean validate(String emailStr) {
        Matcher matcher = valid_email.matcher(emailStr);
        return matcher.find();
    }
    public static boolean checkPostcode(String postCode) {
    	int lengthPost=5;
        if (postCode.length() != lengthPost || postCode.charAt(0) == '0') {
            return false;
        }
        if (postCode.length() == lengthPost) {
            for (int i = 0; i < postCode.length(); i++) {
                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
                    return true;
                }
            }
        }
        return true;
    }
        
        public static boolean checkTel(String postCode) {
	    	int lengthPost=10;
	        if (postCode.length() != lengthPost || postCode.charAt(0) != '0') {
	            return false;
	        }
	        if (postCode.length() == lengthPost) {
	            for (int i = 0; i < postCode.length(); i++) {
	                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
	                    return true;
	                }
	            }
	        }
	        return true;
    }
    public static boolean checkNumrue(String postCode) {
    	int lengthPost=3;
        if (postCode.length() > lengthPost) {
            return false;
        }
        if (postCode.length() <=lengthPost) {
            for (int i = 0; i < postCode.length(); i++) {
                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
                    return true;
                }
            }
        }
        return true;
    }
    public static boolean checkNom(String postCode) {
    	 if (postCode.charAt(0)>'Z' || postCode.charAt(0)<'A') {
	            return false;
    	 }
            for (int i = 0; i < postCode.length(); i++) {
                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
                    return false;
                 
            }
        }
        return true;
    }
    public static boolean checkNomVille(String postCode) {
    	//int lengthPost=3;
            for (int i = 0; i < postCode.length(); i++) {
                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
                    return false;
                }
            }
        return true;
    }
    private static void showAlert(Alert.AlertType alertType, Window owner, String message, String title) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
    public static void infoBox(String infoMessage, String headerText, String title) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }
    @FXML
    void save(MouseEvent event) {
    	Window owner = accepter.getScene().getWindow();

    	if (nom.getText().isEmpty() ||  prenom.getText().isEmpty() || email.getText().isEmpty() || num.getText().isEmpty() || nom_rue.getText().isEmpty() ||num_rue.getText().isEmpty() ||nom_ville.getText().isEmpty()|| code_postal.getText().isEmpty()|| comp_adress.getText().isEmpty()) {
	            Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setHeaderText(null);
	            alert.setContentText("Veuillez remplir tous les champs");
	            alert.showAndWait();

	        }else	  if(checkNumrue(num_rue.getText())==false){
	 			showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un num�ro de rue valide", "Erreur");
	 		}else 
	 			if(checkPostcode(code_postal.getText())==false){
	 				showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un code postal valide", "Erreur");
	 			}else 
	 				if(checkNomVille(nom_ville.getText())==false){
	 					showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un nom de ville valide", "Erreur");
	 				}else 
	 					if(checkTel(num.getText())==false){
	 						showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un num�ro de t�l�phone valide", "Erreur");
	 					}else 
	 						if(checkNom(nom.getText())==false){
	 							showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez vous assurer que votre nom commence par une lettre majuscule", "Erreur");
	 						}else
	 							if(checkNom(prenom.getText())==false){
	 								showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez vous assurer que votre pr�nom commence par une lettre majuscule", "Erreur");
	 							}else
    	try {
    		Connection con=Mysqlconnect.ConnectDb();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
           PreparedStatement stmt = con.prepareStatement("UPDATE admin SET nom=?,prenom=?,mail=?,num=?,num_rue=?,nom_rue=?,postal=?,ville=?,comp_add=?");
           	stmt.setString(1, nom.getText());
            stmt.setString(2, prenom.getText());
            stmt.setString(3, email.getText());
            stmt.setString(4, num.getText());
            stmt.setString(5, num_rue.getText());
            stmt.setString(6, nom_rue.getText());
            stmt.setString(7, code_postal.getText());
            stmt.setString(8, nom_ville.getText());
            stmt.setString(9, comp_adress.getText());
            stmt.executeUpdate();
           // Main.showInformationAlertBox("Informations modifi�es avec succ�s");
           
         } catch (Exception e1) {
            e1.printStackTrace();	        }
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
