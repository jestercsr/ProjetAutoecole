package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class Attributionusercontroller implements Initializable,Liste{

	
	  @FXML
	    private ChoiceBox<String> choixtype;

	    @FXML
	    private AnchorPane suivante;

	    ObservableList<String> list;
	    void monchoix(ActionEvent event) {
	    	if(choixtype.getValue()=="Utilisateur poss�dant un moniteur") {
	    		try {
		      	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/usersmoni.fxml"));
		      		 suivante.getChildren().removeAll();
		      		 suivante.getChildren().setAll(parent);
		      		} catch (IOException e) {
		      			
		      			e.printStackTrace();
		      		}
	    	}else {
	    		try {
		      	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/usersmoni2.fxml"));
		      		 suivante.getChildren().removeAll();
		      		 suivante.getChildren().setAll(parent);
		      		} catch (IOException e) {
		      			
		      			e.printStackTrace();
		      		}
	    	}
	    	
	    }
	    @FXML
	     void choixoption() {
	    	list=afficher();
	    	choixtype.setItems(list);
	    	choixtype.setOnAction(this::monchoix);
	    }
	    

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Utilisateur poss�dant un moniteur","Utilisateur sans moniteur"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

}
