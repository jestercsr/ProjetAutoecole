package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DemandeRecapcontrollers implements Initializable{

	@FXML
    private TextArea motif;

    @FXML
    private Button retour;
    
    @FXML
    private AnchorPane tot;

    @FXML
    private Button validate;

    @FXML
    void annuler(MouseEvent event) {
    	 Stage stage = (Stage)tot.getScene().getWindow();
         stage.close();
    }

    @FXML
    void valider(MouseEvent event) throws SQLException {
    	FXMLLoader loader = new FXMLLoader ();
        loader.setLocation(getClass().getResource("/admininterfaces/Validationdemande.fxml"));
        try {
            loader.load();
        } catch (IOException ex) {
            //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
        Validationdemandecontroller modif=loader.getController();
        System.out.println(Validationdemandecontroller.s+"n");
        System.out.println(modif.recuperer1());
    	Connection  connection = Mysqlconnect.ConnectDb();
		PreparedStatement st1=connection.prepareStatement("select * from utilisateurs where mail_user='"+Validationdemandecontroller.s+"'");
			ResultSet res1=st1.executeQuery(); 
			while(res1.next()) {
 		
 		String sql="UPDATE demandeclient set etat='Rejeter' , motif='"+motif.getText()+"' WHERE id_user='"+res1.getString("id_user")+"' and titre='"+Validationdemandecontroller.a+"'";
 		//String sql1="Insert into moniteurs ('"+res.getInt("id_emp")+"','"+res.getString("nom_emp")+"','"+res.getString("prenom_emp")+"','"+res.getString("mail_emp")+"','"+res.getString("num_emp")+"','"+res.getString("code_postal")+"','"+res.getString("nom_ville")+"','"+res.getString("complement_adress")+"','"+res.getString("mot_passe")+"','"+res1.getInt("id_user")+"'";
 		PreparedStatement st2=connection.prepareStatement(sql);
 		st2.execute();
 		
			}
			JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
