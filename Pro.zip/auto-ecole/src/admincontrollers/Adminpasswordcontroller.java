package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;

public class Adminpasswordcontroller implements Initializable{
	Connection cn=null;
	Statement stmt;
	@FXML
    private TextField new_conf;

    @FXML
    private TextField newp;

    @FXML
    private TextField old;

    @FXML
    void annuler(MouseEvent event) {

    }

    @FXML
    void validate(MouseEvent event) throws SQLException {
    	cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
		
    	try {
    				stmt= cn.createStatement();
					ResultSet res=null;
					res=stmt.executeQuery("Select * from admin"); 
					while ( res.next() )
					{
						if(old.getText()==res.getString("mdp")) {
								if(newp.getText()==new_conf.getText()) {
									PreparedStatement stm = cn.prepareStatement("UPDATE admin SET mot_passe='"+newp.getText()+"'");
									stm.execute();
								}else {
									Alert errorAlert = new Alert(AlertType.ERROR);
									errorAlert.setHeaderText("Input not valid");
									errorAlert.setContentText("Les deux mots de passe sont incompatibles");
									errorAlert.showAndWait();}
						}else {
							Alert errorAlert = new Alert(AlertType.ERROR);
							errorAlert.setHeaderText("Input not valid");
							errorAlert.setContentText("L'ancien mot de passe est incorrect");
							errorAlert.showAndWait();
						}

					}
					
				}catch (Exception e1) {
					e1.printStackTrace();	    
					
				}
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
