package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Interface.Liste1;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class Ajoutvehiculecontroller implements Initializable,Liste,Liste1{
	 
	 ObservableList<String> liste;
		ObservableList<String> liste1;
		Connection con=null;
	    PreparedStatement ps=null;
	    ResultSet res=null;
	 @FXML
	    private ChoiceBox<String> etat;
	 
	 	@FXML
	    private AnchorPane suite;

	    @FXML
	    private ChoiceBox<String> type;

	    @FXML
	    private DatePicker entre;

	    @FXML
	    private TextField marque;

	    @FXML
	    private TextField matricule;

	    @FXML
	    private TextField nom;
	    
	    @FXML
	    private AnchorPane total;
	    
	    @FXML
	    void annuler(MouseEvent event) {

	    }

	    @FXML
	    void valider(MouseEvent event) {
	    	
		    	con=Mysqlconnect.ConnectDb();
	    		String val1=nom.getText();
	    		String val2=matricule.getText();
	    		String val3=marque.getText();
	    		String val4=type.getValue();
	    		String val5=etat.getValue();
	    		LocalDate val6=entre.getValue();
	    		if (val1.isEmpty() || val2.isEmpty() || val3.isEmpty() || val4.isEmpty() ||val5.isEmpty() ||val6==null) {
    	            Alert alert = new Alert(Alert.AlertType.ERROR);
    	            alert.setHeaderText(null);
    	            alert.setContentText("Please Fill All DATA");
    	            alert.showAndWait();

    	        } else {
    	        	try {
    	        		con=Mysqlconnect.ConnectDb();
    	        		PreparedStatement st1=con.prepareStatement("select * from vehicules where num_matri='"+matricule.getText()+"'");
    	        		ResultSet res1=st1.executeQuery(); 
    	        	if(res1.next()) {
    	        		JOptionPane.showMessageDialog(null, "Ce v�hicule existe d�j�");
    	        	}else {
    	        		try {
    	        			con=Mysqlconnect.ConnectDb();
    	    	    		String sql="INSERT INTO vehicules(num_matri,nom_vehi,marque_vehic,type_vehi,etat_vehi,date_entre) values ('"+val2+"','"+val1+"','"+val3+"','"+val4+"','"+val5+"','"+val6+"')";
    	    	    		PreparedStatement st=con.prepareStatement(sql);
    	    	    		st.execute();
    	    	    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
    	    	    	}catch(Exception e) {
    	    	    		

    	    		    }
    	        	}
    	        	}catch(Exception ex) {
		    	
		    }}
	    }
	    
	    @FXML
	    void choixetat(MouseEvent event) {
	    	liste1=afficher1();
	    	etat.setItems(liste1);
	    }
	    

	    @FXML
	    void choixtype(MouseEvent event) {
	    	liste=afficher();
	    	type.setItems(liste);
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Automatique","Manuelle"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

	@Override
	public ObservableList<String> afficher1() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Neuf","En cours de r�paration","Endommag�e"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

}
