package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import Mod�les.Clients;
import Mod�les.Demandesupp;
import Mod�les.Vehicule;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import de.jensd.fx.glyphs.GlyphsStack;

public class Userscontroller implements Initializable{
	
    @FXML
    private TableView<Clients> inscritsview;
    @FXML
    private TableColumn<Clients, String> informations;

    @FXML
    private TableColumn<Clients, String> mail;

    @FXML
    private TableColumn<Clients, String> num;

    @FXML
    private TableColumn<Clients, String> permis;
    @FXML
    private TableColumn<Clients,String> idcol;
    @FXML
    private TableColumn<Clients, String> modif_col;
    @FXML
    private TableView<Clients> attenteview;

    @FXML
    private TableColumn<Clients, String> mailattente;
    
    @FXML
    private ImageView delete;

    @FXML
    private TableColumn<Clients, Float> may�;

    @FXML
    private TableColumn<Clients, String> nomattente;

    @FXML
    private TableColumn<Clients, String> numattente;

    @FXML
    private TableColumn<Clients, String> number;
    @FXML
    private TableColumn<Clients, String> permisattente;

    @FXML
    private TableColumn<Clients, Integer> rap;
    @FXML
    private ImageView view;
    public static String m;

    ObservableList<Clients> listu;
    ObservableList<Clients> lista;
	int index=-1;
	Connection con=null;
    PreparedStatement ps=null;
    ResultSet res=null;
    
    @FXML
    void afficheinfos() {
    	
    }
    @FXML
    void listinscrit() {
    	idcol.setCellValueFactory(new PropertyValueFactory<> ("id_user"));
    	informations.setCellValueFactory(new PropertyValueFactory<> ("nom_user"));
    	mail.setCellValueFactory(new PropertyValueFactory<> ("mail_user"));
    	num.setCellValueFactory(new PropertyValueFactory<> ("num_user"));
    	permis.setCellValueFactory(new PropertyValueFactory<> ("permis"));
    	
    	
    	listu=list();
    	inscritsview.setItems(listu);
    }
    @FXML
    void listattente() {
    	number.setCellValueFactory(new PropertyValueFactory<> ("id_user"));
    	nomattente.setCellValueFactory(new PropertyValueFactory<> ("nom_user"));
    	mailattente.setCellValueFactory(new PropertyValueFactory<> ("mail_user"));
    	numattente.setCellValueFactory(new PropertyValueFactory<> ("num_user"));
    	may�.setCellValueFactory(new PropertyValueFactory<> ("mont_pay�"));
    	permisattente.setCellValueFactory(new PropertyValueFactory<> ("permis"));
    	lista=list1();
    	attenteview.setItems(lista);
    }
    public static ObservableList<Clients> list(){
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<Clients> list=FXCollections.observableArrayList();
		int i=1;
		try {
    			PreparedStatement st=con.prepareStatement("Select * from utilisateurs where statut='Termin�' and etat_compte!='Supprim�'");
    			ResultSet res=st.executeQuery(); 
    			while(res.next()) {
    				list.add(new Clients(
    						"U"+res.getInt("id_user"),
    						res.getString("nom_user")+" "+res.getString("prenom_user"),
    						res.getString("mail_user"),
    						res.getString("num_user"),
    						res.getFloat("montantpay�"),
    						res.getString("permis")));
    				i++;
    			}
    		}catch(Exception e) {
    			System.out.println();
    		}
		return list;
	}
    public static ObservableList<Clients> list1(){
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<Clients> list=FXCollections.observableArrayList();
		int i=1;
		try {
    			PreparedStatement st=con.prepareStatement("Select * from utilisateurs where statut='En attente' and etat_compte!='Supprim�'");
    			ResultSet res=st.executeQuery(); 
    			while(res.next()) {
    				list.add(new Clients(
    						"NU"+i,
    						res.getString("nom_user")+" "+res.getString("prenom_user"),
    						res.getString("mail_user"),
    						res.getString("num_user"),
    						res.getFloat("montantpay�"),
    						res.getString("permis")));
    				i++;
    			}
    		}catch(Exception e) {
    			System.out.println();
    		}
		return list;
	}
   @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		listinscrit();
		listattente();
    	delete.setOnMouseClicked(event->{
    		try {
                Clients cli = inscritsview.getSelectionModel().getSelectedItem();
                String query = "DELETE FROM utilisateurs WHERE mail_user='"+cli.getMail_user()+"'";
                Connection  connection = Mysqlconnect.ConnectDb();
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                 preparedStatement.execute();
                 listinscrit();
             } catch (SQLException ex) {
              //   Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
             }
    	});
    	
    	view.setOnMouseClicked(event->{
    		
    		Clients voit = inscritsview.getSelectionModel().getSelectedItem();
    		m=voit.getMail_user();
            FXMLLoader loader = new FXMLLoader ();
            loader.setLocation(getClass().getResource("/admininterfaces/DemandeTermine.fxml"));
            try {
                loader.load();
            } catch (IOException ex) {
                //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            Profilview modi=loader.getController();
          //  modi.setUpdate(true);
            PreparedStatement st2;
			try {
				con=Mysqlconnect.ConnectDb();
				st2 = con.prepareStatement("select * from utilisateurs where mail_user='"+voit.getMail_user()+"'");
				ResultSet res2=st2.executeQuery(); 
	 			while(res2.next()) {
	 				//int a=LocalDate.now().getYear()-res2.getDate("date_nais").getYear();
	 				String b=res2.getString("num_rue")+" "+res2.getString("nom_rue")+", "+res2.getString("compl�ment_adress")+"\n"+res2.getString("code_postal")+" "+res2.getString("nom_ville");
	 				modi.setData(voit.getNom_user(), res2.getString("date_nais"), voit.getMail_user(),voit.getNum_user(), b,res2.getString("permis"));
	 			}
	            	 Parent parent = loader.getRoot();
	                 Stage stage = new Stage();
	                 stage.setScene(new Scene(parent));
	                 stage.initStyle(StageStyle.UTILITY);
	                 stage.show();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 			
    	});
    	
	}
   
   
                  
              }


