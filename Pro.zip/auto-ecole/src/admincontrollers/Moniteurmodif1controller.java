package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class Moniteurmodif1controller implements Initializable,Liste{

	  @FXML
	    private ChoiceBox<String> choiconsigne;

    @FXML
    private AnchorPane suivant;
    ObservableList<String> list;
    void monchoix(ActionEvent event) {
    	choiconsigne.getSelectionModel().getSelectedItem();
    	if(choiconsigne.getValue()=="Attribuer un utilisateur") {
    		try {
         	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/attributionuser.fxml"));
         		 suivant.getChildren().removeAll();
         		 suivant.getChildren().setAll(parent);
         		} catch (IOException e) {
         			
         			e.printStackTrace();
         		}
    	}
    	
    }
   
    @FXML
     void choixoption() {
    	list=afficher();
    	choiconsigne.setItems(list);
    	choiconsigne.setOnAction(this::monchoix);
    }
   
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		System.out.println(list);
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Attribuer un utilisateur","Retirer un utilisateur"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

}
