package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import Mod�les.Demande;
import Mod�les.Demandesupp;
import Mod�les.Evenements;
import Mod�les.Vehicule;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Demandepanelcontroller implements Initializable{
	 ObservableList<Demandesupp> supp;
	 ObservableList<Demande> dem;
	@FXML
    private TableColumn<Demandesupp, Date> date_col;

    @FXML
    private TableView<Demandesupp> demande;

    @FXML
    private ImageView editer;

    @FXML
    private TableColumn<Demandesupp, String> etat_col;

    @FXML
    private TableColumn<Demandesupp, Integer> n_col;

    @FXML
    private TableColumn<Demandesupp, String> nom_col;

    @FXML
    private TableColumn<Demandesupp, String> titre_col;
    
    @FXML
    private TableColumn<Demande, String> cli_col;

    @FXML
    private TableView<Demande> demandes;

    @FXML
    private TableColumn<Demande, Date> dt_col;
    
    @FXML
    private TableColumn<Demandesupp, String> motif_col;

    @FXML
    private ImageView editer1;

    @FXML
    private TableColumn<Demande, String> et_col;

    @FXML
    private TableColumn<Demande, String> h_col;

    @FXML
    private TableColumn<Demande, Integer> num_col;

    @FXML
    private TableColumn<Demande, String> t_col;
    @FXML
    private ImageView refresh;

    @FXML
    private ImageView refresh1;

    
    @FXML
    void Actualiser() {

		n_col.setCellValueFactory(new PropertyValueFactory<> ("num"));
    	titre_col.setCellValueFactory(new PropertyValueFactory<> ("titre"));
    	date_col.setCellValueFactory(new PropertyValueFactory<> ("date"));
    	nom_col.setCellValueFactory(new PropertyValueFactory<> ("users"));
    	motif_col.setCellValueFactory(new PropertyValueFactory<> ("motif"));
    	etat_col.setCellValueFactory(new PropertyValueFactory<> ("etat"));
    	supp=list1();
    	demande.setItems(supp);
    }
    
    @FXML
    void Actualiser1() {

		num_col.setCellValueFactory(new PropertyValueFactory<> ("num"));
    	t_col.setCellValueFactory(new PropertyValueFactory<> ("titre"));
    	dt_col.setCellValueFactory(new PropertyValueFactory<> ("date"));
    	h_col.setCellValueFactory(new PropertyValueFactory<> ("heure"));
    	cli_col.setCellValueFactory(new PropertyValueFactory<> ("users"));
    	et_col.setCellValueFactory(new PropertyValueFactory<> ("etat"));
    	dem=list();
    	demandes.setItems(dem);
    }

    
    public static ObservableList<Demande> list(){
    	Connection con=Mysqlconnect.ConnectDb();
    		ObservableList<Demande> list=FXCollections.observableArrayList();
    		int i=1;
    		try {
        			PreparedStatement st=con.prepareStatement("Select * from demandeclient");
        			ResultSet res=st.executeQuery(); 
        			while(res.next()) {
        				PreparedStatement sti=con.prepareStatement("Select * from utilisateurs where id_user='"+res.getInt("id_user")+"'");
	        			ResultSet resi=sti.executeQuery(); 
	        			while(resi.next())  {
		        				list.add(new Demande(i,
	    								res.getString("titre"),
	    								res.getDate("date") , 
	    								res.getString("heure"),
	    								resi.getString("nom_user")+" "+resi.getString("prenom_user"), 
	    								res.getString("etat")));
	    					i++;
		        			}
	        			}
    						
        					
        			//}
        			
        		}catch(Exception e) {
        			e.printStackTrace();
        		}
    		return list;
    	}
    
    public static ObservableList<Demandesupp> list1(){
    	Connection con=Mysqlconnect.ConnectDb();
    		ObservableList<Demandesupp> list=FXCollections.observableArrayList();
    		int i=1;
    		try {
        			PreparedStatement st=con.prepareStatement("Select * from demandesupp");
        			ResultSet res=st.executeQuery(); 
        			while(res.next()) {
        				PreparedStatement sti=con.prepareStatement("Select * from utilisateurs where id_user='"+res.getInt("id_user")+"'");
	        			ResultSet resi=sti.executeQuery(); 
	        			while(resi.next()) {
		        				list.add(new Demandesupp(i,
	    								res.getString("titre"),
	    								res.getDate("date") , 
	    								resi.getString("nom_user")+" "+resi.getString("prenom_user"), 
	    								res.getString("motif"),
	    								res.getString("etat")));
	    					i++;
		        			}
    						
        					
        			//}
        			}
        		}catch(Exception e) {
        			e.printStackTrace();
        		}
    		return list;
    	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Actualiser();
		Actualiser1();
		
		editer.setOnMouseClicked(event->{
		
			Demande voit = demandes.getSelectionModel().getSelectedItem();
		//  modi.setUpdate(true);
           System.out.println(voit.toString());
            	FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/admininterfaces/Validationdemande.fxml"));
                try {
                    loader.load();
                } catch (IOException ex) {
                    //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
                }
            	Validationdemandecontroller modi=loader.getController();
            	 if(voit.getEtat().equals("En attente")) {
            	 modi.setData(voit.getTitre(), voit.getUsers(), voit.getDate().toString(), voit.getHeure());
                 Parent parent = loader.getRoot();
                 Stage stage = new Stage();
                 stage.setScene(new Scene(parent));
                 stage.initStyle(StageStyle.UTILITY);
                 stage.show();
            	
            }else {
            	JOptionPane.showMessageDialog(null, "Cette demande a d�j� �t� trait�");
            	//System.out.println();
            }
            
		});
		editer1.setOnMouseClicked(event->{
			Demandesupp voit = demande.getSelectionModel().getSelectedItem();
            FXMLLoader loader = new FXMLLoader ();
            loader.setLocation(getClass().getResource("/admininterfaces/Suppdemande.fxml"));
            try {
                loader.load();
            } catch (IOException ex) {
                //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            Suppdemandecontroller modi=loader.getController();
          //  modi.setUpdate(true);
            if(!voit.getEtat().equals("En attente")) {
            	JOptionPane.showMessageDialog(null, "Cette demande a d�j� �t� trait�");
            }else {
            	 modi.setData(voit.getTitre(), voit.getUsers(), voit.getDate().toString(), voit.getMotif());
                 Parent parent = loader.getRoot();
                 Stage stage = new Stage();
                 stage.setScene(new Scene(parent));
                 stage.initStyle(StageStyle.UTILITY);
                 stage.show();
            }
          
		});
		refresh.setOnMouseClicked(event->{
			Actualiser1();
		});
		refresh1.setOnMouseClicked(event->{
			Actualiser();
		});
		
	}

}
