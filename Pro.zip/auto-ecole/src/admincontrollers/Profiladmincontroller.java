package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Profiladmincontroller implements Initializable{
	
	@FXML
    private AnchorPane interieur;

    @FXML
    private Label menu;

    @FXML
    private Label menuclose;

    @FXML
    private AnchorPane proadmin;

    @FXML
    private Button retour;

    @FXML
    private AnchorPane slider;
    @FXML
    private Label titre;
    
    @FXML
    private Button disconn;

    @FXML
    private Button mdp;

 
    @FXML
    void disconnect(MouseEvent event) {
    	  Stage stage = (Stage)proadmin.getScene().getWindow();
          stage.close();
    }


    @FXML
    void mot_pase(MouseEvent event) {
    	titre.setText("MOT DE PASSE");
    	try {
     	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/Adminpassword.fxml"));
     		 interieur.getChildren().removeAll();
     		 interieur.getChildren().setAll(parent);
     		} catch (IOException e) {
     			
     			e.printStackTrace();
     		}
    	
    	TranslateTransition slide=new TranslateTransition();
		slide.setDuration(Duration.seconds(0.5));
		slide.setNode(slider);
		
		slide.setToX(-307);
		slide.play();
    }

    @FXML
    void infos(MouseEvent event) {
    	titre.setText("INFORMATIONS PERSONELLES");
    	try {
     	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/admininformations.fxml"));
     		 interieur.getChildren().removeAll();
     		 interieur.getChildren().setAll(parent);
     		} catch (IOException e) {
     			
     			e.printStackTrace();
     		}
    	
    	TranslateTransition slide=new TranslateTransition();
		slide.setDuration(Duration.seconds(0.5));
		slide.setNode(slider);
		
		slide.setToX(-307);
		slide.play();
		
		
    }
    

    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		retour.setOnMouseClicked(event->{
	    	try {
	      	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/Accueil.fxml"));
	      		 proadmin.getChildren().removeAll();
	      		 proadmin.getChildren().setAll(parent);
	      		} catch (IOException e) {
	      			
	      			e.printStackTrace();
	      		}
		});
		slider.setTranslateX(-307);
		
		
		menu.setOnMouseClicked(event->{
			TranslateTransition slide=new TranslateTransition();
			slide.setDuration(Duration.seconds(0.5));
			slide.setNode(slider);
			
			slide.setToX(0);
			slide.play();
			
			slider.setTranslateX(-307);
			
			slide.setOnFinished((ActionEvent e)->{
				menu.setVisible(false);
				menuclose.setVisible(true);
			});
		});
		
		menuclose.setOnMouseClicked(event->{
			TranslateTransition slide=new TranslateTransition();
			slide.setDuration(Duration.seconds(0.5));
			slide.setNode(slider);
			
			slide.setToX(-307);
			slide.play();
		
			slider.setTranslateX(0);
			
			slide.setOnFinished((ActionEvent e)->{
				menu.setVisible(true);
				menuclose.setVisible(false);
			});
		});
		
	}

}
