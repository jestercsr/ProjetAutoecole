package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Mod�les.Moniteur;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Moniteurcontroller implements Initializable{
	
		ObservableList<Moniteur> listmon;
		Connection con=null;
	    PreparedStatement ps=null;
	    ResultSet res=null;
	    @FXML
	    private AnchorPane changement;
	 @FXML
	    private TableColumn<Moniteur, String> id_col;

	    @FXML
	    private TableColumn<Moniteur, String> mail_col;

	    @FXML
	    private TableColumn<Moniteur, String> nom_col;

	    @FXML
	    private TableColumn<Moniteur, String> num_col;

	    @FXML
	    private TableColumn<Moniteur, String> users_assi;
	    @FXML
	    private TableView<Moniteur> moni;
	    
	    @FXML
	    private ImageView add;

	    @FXML
	    void modifier(MouseEvent event) {
	    	
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/moniteurmodif.fxml"));
	    		changement.getChildren().removeAll();
	    		 changement.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void Actualiser() throws SQLException {
	    	id_col.setCellValueFactory(new PropertyValueFactory<> ("id_emp"));
	    	nom_col.setCellValueFactory(new PropertyValueFactory<> ("nom_emp"));
	    	mail_col.setCellValueFactory(new PropertyValueFactory<> ("mail_emp"));
	    	num_col.setCellValueFactory(new PropertyValueFactory<> ("num_emp"));
	    	users_assi.setCellValueFactory(new PropertyValueFactory<> ("id_user"));
	    	listmon=list();
	    	moni.setItems(listmon);
	    }
	    public static ObservableList<Moniteur> list() throws SQLException{
	    	Connection con=Mysqlconnect.ConnectDb();
	    		ObservableList<Moniteur> list=FXCollections.observableArrayList();
	    		
	        				PreparedStatement sti=con.prepareStatement("Select * from utilisateurs where tuteur!='0' and etat_compte!='Supprim�'");
		        			ResultSet resi=sti.executeQuery(); 
		        			while(resi.next()) {
		        				try {
		    	        			PreparedStatement st=con.prepareStatement("Select * from moniteurs where id_emp='"+resi.getInt("tuteur")+"'");
		    	        			ResultSet res=st.executeQuery(); 
		    	        			
		    	        			while(res.next()) {
		        				list.add(new Moniteur("M"+res.getInt("id_emp"),
	    								res.getString("nom_emp")+" "+res.getString("prenom_emp"), 
	    								res.getString("mail_emp"), 
	    								res.getString("num_emp"), 
	    								resi.getString("nom_user")+" "+resi.getString("prenom_user")));
		        					
		        			}
	    						
	        					
	        			}catch(Exception e) {
		        			e.printStackTrace();
	        		
	        		}
		        		}
	    		return list;
	    	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
			Actualiser();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		add.setOnMouseClicked(event->{
			try {
	      	   	Parent parent=FXMLLoader.load(getClass().getResource("/admininterfaces/Ajoutmoniteur.fxml"));
	      		Scene scene=new Scene(parent);
	      		Stage stage=new Stage();
	      		stage.setScene(scene);
	      		stage.initStyle(StageStyle.UTILITY);
	      		stage.show();
	      		} catch (IOException e) {
	      			
	      			e.printStackTrace();
	      		}
		});
	}

}
