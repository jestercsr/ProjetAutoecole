package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class Offremodifcontroller implements Initializable{
	
	Connection con;
	 @FXML
	    private TextArea desc;

	 @FXML
	    private Label nom;

	    @FXML
	    private TextField tarif;

	    @FXML
	    private Button valider;

	    @FXML
	    private Button annul;
	    
	    public static boolean checkTarif(String postCode) {
	    	//int lengthPost=3;
	            for (int i = 0; i < postCode.length(); i++) {
	                if (i >= 0 && Character.isLetter(postCode.charAt(i))) {
	                    return false;
	                }
	            }
	        return true;
	    }

	    @FXML
	    void confirmer(MouseEvent event) {
	    	 if (tarif.getText().isEmpty() ||  desc.getText().isEmpty() ) {
	 	            Alert alert = new Alert(Alert.AlertType.ERROR);
	 	            alert.setHeaderText(null);
	 	            alert.setContentText("Veillez remplir tous les champs");
	 	            alert.showAndWait();

	 	        } else
	    	if(checkTarif(tarif.getText())==true) {
	    		if(nom.getText()=="LES PERMIS MOTOS :CATEGORIE A") {
	    			try {
			    		con=Mysqlconnect.ConnectDb();
			    		Float val1=Float.valueOf(tarif.getText());
			    		String val2=desc.getText();
			    		
			    		String sql="Update offre set tarif='"+val1+"',description='"+val2+"' where nom_offre='offre A'";
			    		PreparedStatement st=con.prepareStatement(sql);
			    		st.execute();
			    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
			    	}catch(Exception e) {
			    		e.printStackTrace();
			    	}
	    		}if(nom.getText()=="LES PERMIS VOITURE: CATEGORIE B") {
	    			try {
			    		con=Mysqlconnect.ConnectDb();
			    		Float val1=Float.valueOf(tarif.getText());
			    		String val2=desc.getText();
			    		
			    		String sql="Update offre set tarif='"+val1+"',description='"+val2+"' where nom_offre='offre B'";
			    		PreparedStatement st=con.prepareStatement(sql);
			    		st.execute();
			    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
			    	}catch(Exception e) {
			    		e.printStackTrace();
			    	}
	    		}if(nom.getText()=="LES PERMIS POIDS LOURD DE CATEGORIE C") {
	    			try {
			    		con=Mysqlconnect.ConnectDb();
			    		Float val1=Float.valueOf(tarif.getText());
			    		String val2=desc.getText();
			    		
			    		String sql="Update offre set tarif='"+val1+"',description='"+val2+"' where nom_offre='offre C'";
			    		PreparedStatement st=con.prepareStatement(sql);
			    		st.execute();
			    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
			    	}catch(Exception e) {
			    		e.printStackTrace();
			    	}
	    		}if(nom.getText()=="LES PERMIS POIDS LOURD DE CATEGORIE D") {
	    			try {
			    		con=Mysqlconnect.ConnectDb();
			    		Float val1=Float.valueOf(tarif.getText());
			    		String val2=desc.getText();
			    		
			    		String sql="Update offre set tarif='"+val1+"',description='"+val2+"' where nom_offre='offre D'";
			    		PreparedStatement st=con.prepareStatement(sql);
			    		st.execute();
			    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
			    	}catch(Exception e) {
			    		e.printStackTrace();
			    	}
	    		}
	    		
	    	}else {
	    		 Alert alert = new Alert(Alert.AlertType.ERROR);
	 	            alert.setHeaderText(null);
	 	            alert.setContentText("Veillez entre un tarif correct");
	 	            alert.showAndWait();
	    	}
	    	
	    }

	    @FXML
	    void annuler(MouseEvent event) {

	    }
	    
	    void setData(String a,String b,String c){
	    	this.nom.setText(a);
	    	this.tarif.setText(b);
	    	this.desc.setText(c);
	    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
