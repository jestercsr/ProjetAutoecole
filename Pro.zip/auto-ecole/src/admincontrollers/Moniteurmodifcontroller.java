package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Interface.Liste1;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.layout.AnchorPane;

public class Moniteurmodifcontroller implements Initializable,Liste1{
	ObservableList<String> list=afficher1();
	 @FXML
	    private ChoiceBox<String> choixmoni;
	 @FXML
	    private Label id;
	 
	 public static String result;

    @FXML
    private AnchorPane suivant;
   
    @FXML
    void monchoix(ActionEvent event) {
    		result=choixmoni.getValue();
    	try {
      	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/moniteurmodif1.fxml"));
      		 suivant.getChildren().removeAll();
      		 suivant.getChildren().setAll(parent);
      		} catch (IOException e) {
      			
      			e.printStackTrace();
      		}
    	
    }
   
    @FXML
    void afficher() {
    	choixmoni.setItems(afficher1());
    	
    	//choixmoni.setSelectionModel((SingleSelectionModel<String>) afficher1());
    	choixmoni.setOnAction(this::monchoix);
    }
    public ObservableList<String> afficher1(){
    	Connection con=Mysqlconnect.ConnectDb();
    		ObservableList<String> list1=FXCollections.observableArrayList();
    		try {
        			PreparedStatement st=con.prepareStatement("Select * from moniteurs");
        			ResultSet res=st.executeQuery(); 
        			while(res.next()) {
        				//PreparedStatement sti=con.prepareStatement("Select * from utilisateurs where nom_user='"+res.getString("id_user")+"'");
            			//ResultSet resi=sti.executeQuery(); 
            			//while(resi.next()) {
    						list1.add(res.getString("nom_emp")+" "+res.getString("prenom_emp"));
        					
        			//}
        			}
        		}catch(Exception e) {
        			System.out.println();
        		}
    		return list1;
    	}
	public String recuperer() {
		return id.getText();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		//choixmoni.setItems(afficher1());
		//System.out.println(choixmoni.getItems());
		//System.out.println(afficher1());
		//choixmoni.getSelectionModel().getSelectedItem()
		//afficher();
		//monchoix(null);
		//System.out.println(choixmoni.getValue());
		}

	

}
