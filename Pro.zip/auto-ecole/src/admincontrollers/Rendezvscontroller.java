package admincontrollers;

import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Mod�les.Evenements;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class Rendezvscontroller implements Initializable, Liste{
	 ObservableList<Evenements> listeve;

	   	Connection con=null;
	       PreparedStatement ps=null;
	       ResultSet res=null;
	
	@FXML
    private TableColumn<Evenements, Date> date_col;

    @FXML
    private TextField heured;

    @FXML
    private TableColumn<Evenements, String> heuredeb_col;

    @FXML
    private  TextField heuref;
    
    @FXML
    private TextField titres;

    @FXML
    private TableColumn<Evenements, String> heurefino_col;

    @FXML
    private TableColumn<Evenements, String> id_user;

    @FXML
    private TableColumn<Evenements, String> moni_user;
	
	@FXML
    private TableColumn<Evenements, Integer> n_col;

    @FXML
    private TableView<Evenements> plannings;

    @FXML
    private TableColumn<Evenements, String> titre;
    
    @FXML
    private    DatePicker dt;

    @FXML
    private ChoiceBox<String> usercon;
    
    ObservableList<String> list;

    @FXML
    void selectuser(MouseEvent event) {
    	list=afficher();
    	usercon.setItems(list);
    }
    
    private void clearFields() {
        titres.clear();
        heured.clear();
        heuref.clear();
        usercon.setValue(null);
      //  moniteu.clear();
        dt.setValue(null);
    }
    @FXML
    void supprimer(MouseEvent event) {
    	try {
    		con=Mysqlconnect.ConnectDb();
    		String val1=titres.getText();
    		String val2=heured.getText();
    		String val3=heuref.getText();
    		String val4=usercon.getValue();
    		//String val5=moniteu.getText();
    		LocalDate val6=dt.getValue();
    		String[] NPTab1 = val4.split(" ");
				PreparedStatement st=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\" ");
	 			ResultSet res=st.executeQuery(); 
	 			while(res.next()) {
    		
    		String sql="DELETE from seances where nom_eve='"+val1+"' and date_eve='"+val6+"'and heure_debut='"+val2+"' and heure_fin='"+val3+"' and id_user='"+res.getString("id_user")+"'and id_emp='"+res.getInt("tuteur")+"'";
    		
    		PreparedStatement st1=con.prepareStatement(sql);
    		st1.execute();
    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
    		Actualiser();
    		clearFields();
	 			}
    	}catch(Exception e) {
    		
    	}
    }
    @FXML
    void Actualiser() {

		n_col.setCellValueFactory(new PropertyValueFactory<> ("num"));
    	titre.setCellValueFactory(new PropertyValueFactory<> ("nom_eve"));
    	heuredeb_col.setCellValueFactory(new PropertyValueFactory<> ("heure_deb"));
    	heurefino_col.setCellValueFactory(new PropertyValueFactory<> ("heure_fin"));
    	date_col.setCellValueFactory(new PropertyValueFactory<> ("date_eve"));
    	id_user.setCellValueFactory(new PropertyValueFactory<> ("nom_user"));
    	moni_user.setCellValueFactory(new PropertyValueFactory<> ("nom_emp"));
    	listeve=list();
    	plannings.setItems(listeve);
    }
    int index=-1;
    @FXML
   void getSelected(MouseEvent event) {
	   index=plannings.getSelectionModel().getSelectedIndex();
	   if(index==-1) {
		   
		   return;
	   }else {
		   
		   titres.setText(titre.getCellData(index).toString());
		   heured.setText(heuredeb_col.getCellData(index).toString());
		   heuref.setText(heurefino_col.getCellData(index).toString());
		   usercon.setValue(id_user.getCellData(index).toString());
		  // moniteu.setText(moni_user.getCellData(index).toString());
		   dt.setValue(date_col.getCellData(index).toLocalDate());
	 			
	   }
   }
   
    @FXML
    void modifier(MouseEvent event) {
    	try {
    		con=Mysqlconnect.ConnectDb();
    		String val1=titres.getText();
    		String val2=heured.getText();
    		String val3=heuref.getText();
    		String val4=usercon.getValue();
    		//String val5=moniteu.getText();
    		LocalDate val6=dt.getValue();
    		String[] NPTab1 = usercon.getValue().split(" ");
				PreparedStatement st=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\"  and statut!='En attente'");
	 			ResultSet res=st.executeQuery(); 
	 			while(res.next()) {
    		
    		String sql="Update seances set nom_eve='"+val1+"',date_eve='"+val6+"',heure_debut='"+val2+"',heure_fin='"+val3+"',id_user='"+val4+"',id_emp='"+res.getInt("tuteur")+"' where nom_eve='"+val1+"'";
    		PreparedStatement st1=con.prepareStatement(sql);
    		st1.execute();
    		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
    		Actualiser();
    		clearFields();
	 			}
    	}catch(Exception e) {
    		
    	}

    }
    public static ObservableList<Evenements> list(){
    	Connection con=Mysqlconnect.ConnectDb();
    		ObservableList<Evenements> list=FXCollections.observableArrayList();
    		int i=1;
    		try {
        			PreparedStatement st=con.prepareStatement("Select * from seances");
        			ResultSet res=st.executeQuery(); 
        			while(res.next()) {
        				PreparedStatement sti=con.prepareStatement("Select * from utilisateurs where id_user='"+res.getInt("id_user")+"'");
	        			ResultSet resi=sti.executeQuery(); 
	        			while(resi.next()) {
	        				PreparedStatement ste=con.prepareStatement("Select * from moniteurs where id_emp='"+resi.getInt("tuteur")+"'");
		        			ResultSet rese=ste.executeQuery(); 
		        			while(rese.next()) {
		        				list.add(new Evenements(i,
	    								res.getString("nom_eve"),
	    								res.getDate("date_eve") , 
	    								res.getString("heure_debut"), 
	    								res.getString("heure_fin"), 
	    								resi.getString("nom_user")+" "+resi.getString("prenom_user"), 
	    								rese.getString("nom_emp")+" "+rese.getString("prenom_emp")));
	    					i++;
		        			}
	        			}
    						
        					
        			//}
        			}
        		}catch(Exception e) {
        			System.out.println();
        		}
    		return list;
    	}
    public static boolean checkNomVille(String postCode) {
    	//int lengthPost=3;
            for (int i = 0; i < postCode.length(); i++) {
                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
                    return false;
                }
            }
        return true;
    }
    public static boolean checkHeure(String postCode) {
    	int lengthPost=5;
    	if(postCode.length()!=lengthPost) {
    		return false;
    	}
    	else if(postCode.length()==lengthPost) {
    	if (postCode.charAt(0)>'2' || postCode.charAt(0)<'0') {
            return false;
	 }else {
		 if (postCode.charAt(1)>'9' || postCode.charAt(1)<'0') {
	            return false;
		 }else {
			 if (postCode.charAt(2)!='H') {
		            return false;
			 }else {
				 if (postCode.charAt(3)>'5' || postCode.charAt(3)<'0') {
			            return false;
				 }else {
					 if (postCode.charAt(4)>'9' || postCode.charAt(4)<'0') {
				            return false;
				    	}
				 }
			    	
			 }
		    	
		 }
	    	
    	
	 }
    	}
  
    	  return true;
    }
    
    public boolean EvenementsExistant(LocalDate a,String b,String c,String d,String e) throws SQLException {
    	con=Mysqlconnect.ConnectDb();
    	String[] NPTab1 = c.split(" ");
			PreparedStatement st=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\" ");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				con=Mysqlconnect.ConnectDb();
		    	PreparedStatement st1=con.prepareStatement("select * from seances where id_user='"+res.getInt("id_user")+"' and nom_eve='"+b+"' and heure_debut='"+d+"' and heure_fin='"+e+"' and date_eve='"+a+"'");
					ResultSet res1=st1.executeQuery(); 
					return res1.next();
			}
    	return false;
    }
    
    public int compare(String a,String b) {
    	return a.compareTo(b);
    }
   
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			Actualiser();
		    
		}
		 @FXML
		    void ins�rer(MouseEvent event) throws SQLException {
			 if (titres.getText().isEmpty() ||  heured.getText().isEmpty() || heuref.getText().isEmpty() || usercon.getValue().isEmpty() ||dt.getValue()==null) {
 	            Alert alert = new Alert(Alert.AlertType.ERROR);
 	            alert.setHeaderText(null);
 	            alert.setContentText("Veillez remplir tous les champs");
 	            alert.showAndWait();

 	        }else 
 				if(checkNomVille(titres.getText())==false){
 					 Alert alert = new Alert(Alert.AlertType.ERROR);
 	 	            alert.setHeaderText(null);
 	 	            alert.setContentText("Veillez entrer un titre valide");
 	 	            alert.showAndWait();
 				}else 
	 				if(checkNomVille(usercon.getValue())==false){
	 					 Alert alert = new Alert(Alert.AlertType.ERROR);
	 	 	            alert.setHeaderText(null);
	 	 	            alert.setContentText("Veillez entrer un nom d'utilisateur valide");
	 	 	            alert.showAndWait();
	 				}else if(dt.getValue().isBefore(LocalDate.now())){
	 					Alert alert = new Alert(Alert.AlertType.ERROR);
	 	 	            alert.setHeaderText(null);
	 	 	            alert.setContentText("Veillez entrer une date valide");
	 	 	            alert.showAndWait();
	 				}
			 else 
    	 				if(checkHeure(heured.getText())==false){
    	 					 Alert alert = new Alert(Alert.AlertType.ERROR);
    	 	 	            alert.setHeaderText(null);
    	 	 	            alert.setContentText("Veillez entrer une heure valide \n Format: 11H33");
    	 	 	            alert.showAndWait();
    	 				}  else 
        	 				if(checkHeure(heuref.getText())==false){
       	 					 Alert alert = new Alert(Alert.AlertType.ERROR);
       	 	 	            alert.setHeaderText(null);
       	 	 	            alert.setContentText("Veillez entrer une heure valide \n Format: 11H33");
       	 	 	            alert.showAndWait();
       	 				}else 
        	 				if(compare(heured.getText(),heuref.getText())>0 || compare(heured.getText(),heuref.getText())==0){
          	 					 Alert alert = new Alert(Alert.AlertType.ERROR);
          	 	 	            alert.setHeaderText(null);
          	 	 	            alert.setContentText("Veillez vous assurer que l'heure de d�but est inf�rieure � celle de fin");
          	 	 	            alert.showAndWait();
          	 				}else 
            	 				if(compare(heured.getText(),heuref.getText())==0){
             	 					 Alert alert = new Alert(Alert.AlertType.ERROR);
             	 	 	            alert.setHeaderText(null);
             	 	 	            alert.setContentText("Veillez vous assurer que l'heure de d�but soit diff�rent de celle de fin");
             	 	 	            alert.showAndWait();
             	 				}
            	 				else 
                	 				if(EvenementsExistant(dt.getValue(), titres.getText(), usercon.getValue(),heured.getText(),heuref.getText())==true){
                 	 					 Alert alert = new Alert(Alert.AlertType.ERROR);
                 	 	 	            alert.setHeaderText(null);
                 	 	 	            alert.setContentText("Cet Evenement existe dej�");
                 	 	 	            alert.showAndWait();
                 	 				}
             	 				
			 
    	 				else {
 	        	try {
 	        		con=Mysqlconnect.ConnectDb();
 	        	//	String s=" ";
 	        		String[] NPTab1 = usercon.getValue().split(" ");
	 				PreparedStatement st=con.prepareStatement("select * from utilisateurs where prenom_user = \""+NPTab1[1]+"\" AND nom_user = \""+NPTab1[0]+"\" ");
 	 	 			ResultSet res=st.executeQuery(); 
 	 	 		 
	 	 				while(res.next()) {
	 	 	 	 			
								con = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
								PreparedStatement stmt = con.prepareStatement("INSERT INTO seances ( nom_eve, date_eve, heure_debut, heure_fin, id_user,id_emp) VALUES (?,?,?,?,?,?)");
								stmt.setString(1, titres.getText());
								stmt.setString(2, dt.getValue().toString());
								stmt.setString(3, heured.getText());
								stmt.setString(4, heuref.getText());
								stmt.setString(5, res.getString("id_user"));
								stmt.setString(6, res.getString("tuteur"));
								stmt.executeUpdate();
			           
								//clear fields
								Actualiser();
								clearFields();
	 	 				}
	 	 			}catch (Exception ex) {
					/*Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setHeaderText(null);
					alert.setContentText("Ce moniteur ne figure pas dans votre liste");
					alert.showAndWait();*/
					ex.printStackTrace();
			
	 			} 
	 	 			}
 	 	 			
		 }

		@Override
		public ObservableList<String> afficher() {
			// TODO Auto-generated method stub
			Connection con=Mysqlconnect.ConnectDb();
    		ObservableList<String> list=FXCollections.observableArrayList();
    		//String s=" ";
    		try {
        			PreparedStatement st=con.prepareStatement("select * from utilisateurs where statut='Termin�' and tuteur!='0' and etat_compte!='Supprim�'");
        			ResultSet res=st.executeQuery(); 
        			while(res.next()) {
        				//PreparedStatement sti=con.prepareStatement("Select * from utilisateurs where nom_user='"+res.getString("id_user")+"'");
            			//ResultSet resi=sti.executeQuery(); 
            			//while(resi.next()) {
    						list.add(res.getString("nom_user")+" "+res.getString("prenom_user"));
        					
        			//}
        			}
        		}catch(Exception e) {
        			System.out.println();
        		}
    		return list;
		}
		 


}
