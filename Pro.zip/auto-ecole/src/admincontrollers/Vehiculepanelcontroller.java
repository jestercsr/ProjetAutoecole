package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Mod�les.Vehicule;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Vehiculepanelcontroller implements Initializable{
	 ObservableList<Vehicule> listvehi;

	   	Connection con=null;
	       PreparedStatement ps=null;
	       ResultSet res=null;
	    @FXML
	    private ImageView ajouter;

	    @FXML
	    private ImageView editer;

	    @FXML
	    private TableColumn<Vehicule, Date> entretien;

	    @FXML
	    private TableColumn<Vehicule, String> marque;

	    @FXML
	    private TableColumn<Vehicule, String> matricule;

	    @FXML
	    private TableColumn<Vehicule, String> nom;

	    @FXML
	    private TableColumn<Vehicule, Integer> number;

	    @FXML
	    private ImageView supprimer;
	    
	    @FXML
	    private ImageView refresh;
	    
	    @FXML
	    private TableColumn<Vehicule, String> etat;

	    @FXML
	    private TableColumn<Vehicule, String> type;

	    @FXML
	    private TableView<Vehicule> voiture;
	    
	    @FXML
	    void Actualiser() {

			number.setCellValueFactory(new PropertyValueFactory<> ("num"));
	    	matricule.setCellValueFactory(new PropertyValueFactory<> ("matricule"));
	    	nom.setCellValueFactory(new PropertyValueFactory<> ("nom"));
	    	marque.setCellValueFactory(new PropertyValueFactory<> ("marque"));
	    	type.setCellValueFactory(new PropertyValueFactory<> ("type"));
	    	etat.setCellValueFactory(new PropertyValueFactory<> ("etat"));
	    	entretien.setCellValueFactory(new PropertyValueFactory<> ("entret"));
	    	listvehi=list5();
	    	voiture.setItems(listvehi);
	    }
	    
	    public static ObservableList<Vehicule> list5(){
	    	Connection con=Mysqlconnect.ConnectDb();
	    		ObservableList<Vehicule> list=FXCollections.observableArrayList();
	    		int i=1;
	    		try {
						
						
	        			PreparedStatement st=con.prepareStatement("SELECT * FROM vehicules");
	        			
	        			ResultSet res=st.executeQuery(); 
	        			while(res.next()) {
	        				
	    						list.add(new Vehicule(i,
	    								res.getString("num_matri"),
	    								res.getString("nom_vehi"),
	    								res.getString("marque_vehic"), 
	    								res.getString("type_vehi"), 
	    								res.getString("etat_vehi"),
	    								res.getDate("date_entre")));
	        					i++;
	        			}	
	        			
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
	    		return list;
	    	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Actualiser();
		
		supprimer.setOnMouseClicked(event->{
			try {
               Vehicule vehi = voiture.getSelectionModel().getSelectedItem();
               String query = "DELETE FROM vehicules WHERE num_matri='"+vehi.getMatricule()+"'";
               Connection  connection = Mysqlconnect.ConnectDb();
               PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.execute();
               Actualiser();
                
            } catch (SQLException ex) {
             //   Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
            }
		});
		ajouter.setOnMouseClicked(event->{
			try {
	      	   	Parent parent=FXMLLoader.load(getClass().getResource("/admininterfaces/ajoutvehicule.fxml"));
	      		Scene scene=new Scene(parent);
	      		Stage stage=new Stage();
	      		stage.setScene(scene);
	      		stage.initStyle(StageStyle.UTILITY);
	      		stage.show();
	      		} catch (IOException e) {
	      			
	      			e.printStackTrace();
	      		}
		});
		
		editer.setOnMouseClicked(event->{
			Vehicule voit = voiture.getSelectionModel().getSelectedItem();
             FXMLLoader loader = new FXMLLoader ();
             loader.setLocation(getClass().getResource("/admininterfaces/modifvehi.fxml"));
             try {
                 loader.load();
             } catch (IOException ex) {
                 //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
             }
             
             Modifvehicontroller modi=loader.getController();
           //  modi.setUpdate(true);
             modi.setTextField(voit.getNom(),voit.getMatricule(),voit.getMarque(),voit.getType(),voit.getEtat(),voit.getEntret().toLocalDate());
             Parent parent = loader.getRoot();
             Stage stage = new Stage();
             stage.setScene(new Scene(parent));
             stage.initStyle(StageStyle.UTILITY);
             stage.show();
             
				
				
		});
		refresh.setOnMouseClicked(event->{
			Actualiser();
		});
		
	}

}
