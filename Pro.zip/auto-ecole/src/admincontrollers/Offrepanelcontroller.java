package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import controllers.Descriptioncontroller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Offrepanelcontroller implements Initializable{

	 @FXML
	    private ImageView im_a;

	    @FXML
	    private ImageView im_b;

	    @FXML
	    private ImageView im_c;

	    @FXML
	    private ImageView im_d;

	    @FXML
	    private Label nom_a;

	    @FXML
	    private Label nom_b;

	    @FXML
	    private Label nom_c;

	    @FXML
	    private Label nom_d;

	    @FXML
	    private TextArea ta;

	    @FXML
	    private Label tarif_a;

	    @FXML
	    private Label tarif_b;

	    @FXML
	    private Label tarif_c;

	    @FXML
	    private Label tarif_d;

	    @FXML
	    private TextArea tb;

	    @FXML
	    private TextArea tc;

	    @FXML
	    private TextArea td;
	    
	    void permisA() throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre A'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				 nom_a.setText(res.getString("nom_offre"));
				 tarif_a.setText(res.getString("tarif"));
				 ta.setText(res.getString("description"));
			         
			}
	    }
			void permisB() throws SQLException {
		    	Connection con=Mysqlconnect.ConnectDb();
				PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre B'");
				ResultSet res=st.executeQuery(); 
				while(res.next()) {
					 nom_b.setText(res.getString("nom_offre"));
					 tarif_b.setText(res.getString("tarif"));
					 tb.setText(res.getString("description"));
				         
				}
			}
				void permisC() throws SQLException {
			    	Connection con=Mysqlconnect.ConnectDb();
					PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre C'");
					ResultSet res=st.executeQuery(); 
					while(res.next()) {
						 nom_c.setText(res.getString("nom_offre"));
						 tarif_c.setText(res.getString("tarif"));
						 tc.setText(res.getString("description"));
					         
					}
				}
					void permisD() throws SQLException {
				    	Connection con=Mysqlconnect.ConnectDb();
						PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre D'");
						ResultSet res=st.executeQuery(); 
						while(res.next()) {
							 nom_d.setText(res.getString("nom_offre"));
							 tarif_d.setText(res.getString("tarif"));
							 td.setText(res.getString("description"));
						         
						}
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
			permisA();
			permisB();
			permisC();
			permisD();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		im_a.setOnMouseClicked(event->{
			try {
				Connection con=Mysqlconnect.ConnectDb();
				PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre A'");
				ResultSet res=st.executeQuery(); 
				while(res.next()) {
					  FXMLLoader loader = new FXMLLoader ();
				         loader.setLocation(getClass().getResource("/admininterfaces/OffreModif.fxml"));
				         try {
				             loader.load();
				         } catch (IOException ex) {
				             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
				         }
				         
				         Offremodifcontroller modi=loader.getController();
				       //  modi.setUpdate(true);
				        modi.setData("LES PERMIS MOTOS :CATEGORIE A", res.getString("tarif"), res.getString("description"));
				         Parent parent = loader.getRoot();
				         Stage stage = new Stage();
				         stage.setScene(new Scene(parent));
				         stage.initStyle(StageStyle.UTILITY);
				         stage.show();
			}}catch(SQLException e) {
				e.printStackTrace();
			}
			
			         
		});
		
		im_b.setOnMouseClicked(event->{
			try {
				Connection con=Mysqlconnect.ConnectDb();
				PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre B'");
				ResultSet res=st.executeQuery(); 
				while(res.next()) {
					  FXMLLoader loader = new FXMLLoader ();
				         loader.setLocation(getClass().getResource("/admininterfaces/OffreModif.fxml"));
				         try {
				             loader.load();
				         } catch (IOException ex) {
				             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
				         }
				         
				         Offremodifcontroller modi=loader.getController();
				       //  modi.setUpdate(true);
				        modi.setData("LES PERMIS VOITURE: CATEGORIE B", res.getString("tarif"), res.getString("description"));
				         Parent parent = loader.getRoot();
				         Stage stage = new Stage();
				         stage.setScene(new Scene(parent));
				         stage.initStyle(StageStyle.UTILITY);
				         stage.show();
			}}catch(SQLException e) {
				e.printStackTrace();
			}
		});
		
		im_c.setOnMouseClicked(event->{
			try {
				Connection con=Mysqlconnect.ConnectDb();
				PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre C'");
				ResultSet res=st.executeQuery(); 
				while(res.next()) {
					  FXMLLoader loader = new FXMLLoader ();
				         loader.setLocation(getClass().getResource("/admininterfaces/OffreModif.fxml"));
				         try {
				             loader.load();
				         } catch (IOException ex) {
				             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
				         }
				         
				         Offremodifcontroller modi=loader.getController();
				       //  modi.setUpdate(true);
				        modi.setData("LES PERMIS POIDS LOURD DE CATEGORIE C", res.getString("tarif"), res.getString("description"));
				         Parent parent = loader.getRoot();
				         Stage stage = new Stage();
				         stage.setScene(new Scene(parent));
				         stage.initStyle(StageStyle.UTILITY);
				         stage.show();
			}}catch(SQLException e) {
				e.printStackTrace();
			}
		});
		
		im_d.setOnMouseClicked(event->{
			try {
				Connection con=Mysqlconnect.ConnectDb();
				PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre D'");
				ResultSet res=st.executeQuery(); 
				while(res.next()) {
					  FXMLLoader loader = new FXMLLoader ();
				         loader.setLocation(getClass().getResource("/admininterfaces/OffreModif.fxml"));
				         try {
				             loader.load();
				         } catch (IOException ex) {
				             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
				         }
				         
				         Offremodifcontroller modi=loader.getController();
				       //  modi.setUpdate(true);
				        modi.setData("LES PERMIS POIDS LOURD DE CATEGORIE D", res.getString("tarif"), res.getString("description"));
				         Parent parent = loader.getRoot();
				         Stage stage = new Stage();
				         stage.setScene(new Scene(parent));
				         stage.initStyle(StageStyle.UTILITY);
				         stage.show();
			}}catch(SQLException e) {
				e.printStackTrace();
			}
		});
		
	}

}
