package admincontrollers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Interface.Liste1;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class Accueilcontroller implements Initializable,Liste,Liste1{
	 @FXML
	    private Button moniteurs;

	    @FXML
	    private Button plannings;

	    @FXML
	    private AnchorPane receveur;

	    @FXML
	    private Button users;

	    @FXML
	    private Button vehicules;
	    
	    @FXML
	    private Button accueil;
	    @FXML
	    private ImageView profil;
	    @FXML
	    private AnchorPane accueils;
	    @FXML
	    private Button offre;
	    @FXML
	    private Button demande;

	    @FXML
	    void moniteurpanel(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/Moniteurs.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    @FXML
	    void affichage(MouseEvent event) {
	    	
	    }
	    @FXML
	    void accueil(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/affichageaccueil.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    @FXML
	    void demandepanel(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/Demandepanel.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void offrepanel(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/Offrepanel.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }



	    @FXML
	    void planningspanel(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/rendezvs.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	    }

	    @FXML
	    void userpanels(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/users.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//System.out.println("t une merde");
				
				e.printStackTrace();
			}
	    }

	    @FXML
	    void vehiculespanel(MouseEvent event) {
	    	try {
		    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/vehiculepanel.fxml"));
	    		 receveur.getChildren().removeAll();
	    		 receveur.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//System.out.println("t une merde");
				
				e.printStackTrace();
			}
	    }@FXML
	    private ListView<String> currentinscrip;
	    
	    @FXML
	    private ListView<String> currentdemande;

	    @FXML
	    private ListView<String> programmejour;
	    
	    public ObservableList<String> liste() {
	    	Connection con=Mysqlconnect.ConnectDb();
	    	ObservableList<String> listprog=FXCollections.observableArrayList();
		try {
    			PreparedStatement st=con.prepareStatement("SELECT * FROM seances WHERE date_eve=DATE(NOW()) ORDER BY seances.heure_debut ASC");
    			ResultSet res=st.executeQuery(); 
    			while(res.next()) {
    				listprog.add(res.getString("heure_debut")+"-"+ 
							res.getString("heure_fin")+" : "+res.getString("nom_eve")
								+" suivi par M. "+
								res.getString("id_user")+" sous la tutelle de M. "+
								res.getString("id_emp"));
					}
    			programmejour.getItems().addAll(listprog);
    		}catch(Exception e) {
    			System.out.println();
    		}
		return listprog;
	    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		liste();
		afficher();
		afficher1();
		profil.setOnMouseClicked(event->{
			try {
	      	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/profiladmin.fxml"));
	      		 accueils.getChildren().removeAll();
	      		 accueils.getChildren().setAll(parent);
	      		} catch (IOException e) {
	      			
	      			e.printStackTrace();
	      		}
		});
	}
	@Override
	public ObservableList<String> afficher1() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
	try {
			PreparedStatement st=con.prepareStatement("SELECT * FROM utilisateurs WHERE date_insc=DATE(NOW())");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				listprog.add("Le client "+res.getString("nom_user")+" "+ 
						res.getString("prenom_user")+" s'est inscrit sur votre plateforme aujourd'hui ");
				}
			currentinscrip.getItems().addAll(listprog);
		}catch(Exception e) {
			System.out.println();
		}
	return listprog;
	}
	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
    	ObservableList<String> listdem=FXCollections.observableArrayList();
	try {
		PreparedStatement st1=con.prepareStatement("SELECT * FROM demandeclient where date_dem=DATE(NOW()) and etat='En attente'");
		ResultSet res1=st1.executeQuery(); 
		while(res1.next()) {
		PreparedStatement st=con.prepareStatement("SELECT * FROM utilisateurs WHERE id_user='"+res1.getString("id_user")+"' ");
		ResultSet res=st.executeQuery(); 
		while(res.next()) {
			listprog.add("Le client "+res.getString("nom_user")+" "+ 
					res.getString("prenom_user")+" a formul� une demande ");
			}
		}
		currentdemande.getItems().addAll(listprog);
	}catch(Exception e) {
		e.printStackTrace();
	}
	try {
		PreparedStatement st2=con.prepareStatement("SELECT * FROM demandesupp where date=DATE(NOW()) and etat='En attente'");
		ResultSet res2=st2.executeQuery(); 
		while(res2.next()) {
			PreparedStatement st3=con.prepareStatement("SELECT * FROM utilisateurs WHERE id_user='"+res2.getString("id_user")+"' ");
			ResultSet res3=st3.executeQuery(); 
			while(res3.next()) {
				listdem.add("Le client "+res3.getString("nom_user")+" "+ 
						res3.getString("prenom_user")+" a formul� une demande ");
				}
			
			
		}
		currentdemande.getItems().addAll(listdem);
		}catch(Exception e) {
			e.printStackTrace();
		}
	return listprog;
	}

}
