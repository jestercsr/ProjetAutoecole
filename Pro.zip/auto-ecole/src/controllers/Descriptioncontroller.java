package controllers;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class Descriptioncontroller implements Initializable{
	 @FXML
	    private TextArea desc;
	 @FXML
	    private Label titre;
	 
	 void setdesc(String a) {
		 desc.setText(a);
	 }
	 
	 void setTitre(String b) {
		 titre.setText(b);
	 }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
	
	}

}
