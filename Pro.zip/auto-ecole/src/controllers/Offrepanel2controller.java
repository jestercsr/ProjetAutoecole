package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Offrepanel2controller implements Initializable{
	@FXML
    private Button cont;

    @FXML
    private Label eta;

    @FXML
    private Label name;

    @FXML
    private Label nom;

    @FXML
    private Label paye;

    @FXML
    private Label perm;

    @FXML
    private Label permis;

    @FXML
    private Label prenom;

    @FXML
    private Label restant;

    @FXML
    private Label tot;
    
    @FXML
    private HBox act;
    
    public static String titre;
    @FXML
    void continuer(MouseEvent event) throws SQLException {
    	Connection con=Mysqlconnect.ConnectDb();
		PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre C'");
		ResultSet res=st.executeQuery(); 
		while(res.next()) {
			  FXMLLoader loader = new FXMLLoader ();
		         loader.setLocation(getClass().getResource("/Autres/Paiement.fxml"));
		         try {
		             loader.load();
		         } catch (IOException ex) {
		             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
		         }
		         
		         Paiementcontroller modi=loader.getController();
		       //  modi.setUpdate(true);
		        
		         modi.setTitre(titre);
		         modi.setsomme(tot.getText());
		         modi.setpermis(permis.getText());
		         modi.setpaye(paye.getText());
		         modi.setRap(restant.getText());
		         Parent parent = loader.getRoot();
		         Stage stage = new Stage();
		         stage.setScene(new Scene(parent));
		         stage.initStyle(StageStyle.UTILITY);
		         stage.show();
		}
    }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		try {
     		Connection con=Mysqlconnect.ConnectDb();
     		con=Mysqlconnect.ConnectDb();
     		FXMLLoader loader = new FXMLLoader ();
            loader.setLocation(getClass().getResource("/interfaces/Conneion.fxml"));
            try {
                loader.load();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
  	        	 Connexioncontroller modi=loader.getController();
  	        	//int i=1;
  	        	
  	    		 PreparedStatement st=con.prepareStatement("select * from utilisateurs where mail_user='"+Connexioncontroller.MailUser+"'");
  		 			ResultSet res=st.executeQuery(); 
  		 			while(res.next()) {
  		 				nom.setText(res.getString("nom_user"));
  		 				prenom.setText(res.getString("prenom_user"));
  		 				permis.setText(res.getString("permis"));
  		 				paye.setText(res.getString("montantpay�"));
  		 				name.setText(res.getString("nom_user")+" "+res.getString("prenom_user"));
  		 				perm.setText(res.getString("permis"));
  		 			 if(res.getString("permis").equals("A")) {
  			     		titre="LES PERMIS MOTOS :CATEGORIE A";
  			     	}else
  			     		if(res.getString("permis").equals("B")) {
  			     			titre="LES PERMIS MOTOS :CATEGORIE B";
  			         	}else
  			         		if(res.getString("permis").equals("C")) {
  			         			titre="LES PERMIS POIDS LOURD DE CATEGORIE C";
  			             	}else
  			             		if(res.getString("permis").equals("D")) {
  			             			titre="LES PERMIS POIDS LOURD DE CATEGORIE D";
  			                 	}
  		 		    	eta.setText(res.getString("statut"));
  		 		    	if(res.getString("statut").equals("Termin�")) {
  		 		    		act.setVisible(false);
  		 		    		cont.setVisible(false);
  		 		    	}
  		 			 PreparedStatement st1=con.prepareStatement("select * from offre where nom_offre='offre "+res.getString("permis")+"'");
   		 			ResultSet res1=st1.executeQuery(); 
   		 			while(res1.next()) {
  		 				
  		 				tot.setText(res1.getString("tarif"));
  		 				float a=Float.parseFloat(tot.getText())-Float.parseFloat(paye.getText());
  		 		    	restant.setText(Float.toString(a));
  		 				
  		 			}
  		 		}
  		 			
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
	}

}
