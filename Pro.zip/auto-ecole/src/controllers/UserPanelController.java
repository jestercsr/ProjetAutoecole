package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UserPanelController implements Initializable{
		Parent fxml;
		 @FXML
		    private AnchorPane content;

	 	@FXML
	    private Button Disconnect;

	    @FXML
	    private Button compte;

	    @FXML
	    private ImageView retour;

	    @FXML
	    private Label name;

	    @FXML
	    private Button password;

	    @FXML
	    private Label permis;
	    
	    @FXML
	    private AnchorPane gene;
	    
	    @FXML
	    private Label user_name=nomutilisateur();
	   Label nomutilisateur(){
	    	String BDD = "auto-ecole";
			String url = "jdbc:mysql://localhost:3306/" + BDD;
			String user = "root";
			String passwd = "";
			Label utili = null;
			// L'essaie de connexion � votre base de don�es
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection(url, user, passwd);
					Statement st=conn.createStatement();
					ResultSet res=st.executeQuery("Select * from utilisateurs"); 
					while(res.next()) {
						//utili.getText()==res.getString(1)+" "+res.getString(2);
					}
				}catch(Exception e) {
					System.out.println();
				}
			return utili;
	    }

	    @FXML
	    private Button planning;

	    @FXML
	    private Button userinformations;
	    @FXML
	    void Disconnect() {

	    }

	    @FXML
	    void compte() {
	    	try {
	    	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/CompteSettings.fxml"));
    		 content.getChildren().removeAll();
    		 content.getChildren().setAll(parent);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    }

	    @FXML
	    void password() {
	    	try {
				//fxml=FXMLLoader.load(getClass().getResource("/interfaces/UserInformations.fxml"));
				//fxml.getChildrenUnmodifiable();
				//userinformations.getChildrenUnmodifiable().setAll();
	    		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Password.fxml"));
	    		 content.getChildren().removeAll();
	    		 content.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    @FXML
	    void planning() {

	    }
	    @FXML
	    void userinformations() {
	    	try {
				//fxml=FXMLLoader.load(getClass().getResource("/interfaces/UserInformations.fxml"));
				//fxml.getChildrenUnmodifiable();
				//userinformations.getChildrenUnmodifiable().setAll();
	    		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/UserInformations.fxml"));
	    		 content.getChildren().removeAll();
	    		 content.getChildren().setAll(parent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	   

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			
			retour.setOnMouseClicked(event->{
				try {
			   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/AccueilClient.fxml"));
			     		 gene.getChildren().removeAll();
			     		 gene.getChildren().setAll(parent);
			    	}catch(Exception e) {
			    		e.printStackTrace();
			    	}
			});
			
		}

	

}
