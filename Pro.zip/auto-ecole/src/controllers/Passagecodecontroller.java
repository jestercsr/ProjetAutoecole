package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import Interface.Liste1;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.input.MouseEvent;

public class Passagecodecontroller implements Initializable,Liste,Liste1{
	Connection con=null;
	 @FXML
	    private DatePicker date;

	    @FXML
	    private ChoiceBox<String> heure;

	    @FXML
	    private ChoiceBox<String> minute;

	    ObservableList<String> list;
	    ObservableList<String> list1;
	    
	    void Clearfield() {
	    	heure.setValue(null);
	    	minute.setValue(null);
	    	date.setValue(null);
	    }

	    @FXML
	    void annuler(MouseEvent event) {
	    	
	    }

	    @FXML
	    void valider(MouseEvent event) throws SQLException {
	    	 System.out.println(heure.getValue()+" "+minute.getValue());
	    	 if (date.getValue()==null||heure.getValue()==null||minute.getValue()==null) {
	    		 choixoption();
		    	 choixoption1();
	 	            Alert alert = new Alert(Alert.AlertType.ERROR);
	 	            alert.setHeaderText(null);
	 	            alert.setContentText("Veillez remplir tous les champs");
	 	            alert.showAndWait();

	 	        }else
	 	        	try {
	 	        		con=Mysqlconnect.ConnectDb();
	 	        		FXMLLoader loader = new FXMLLoader ();
	 	               loader.setLocation(getClass().getResource("/interfaces/Conneion.fxml"));
	 	               try {
	 	                   loader.load();
	 	               } catch (IOException ex) {
	 	                   ex.printStackTrace();
	 	               }
	 	               
	 	     	        	 Connexioncontroller modi=loader.getController();
	 	     	        	//int i=1;
	 	     	        	
	 	     	    		 PreparedStatement st1=con.prepareStatement("select * from utilisateurs where mail_user='"+Connexioncontroller.MailUser+"'");
	 	     		 			ResultSet res1=st1.executeQuery(); 
	 	     		 		//System.out.println(modi.MailUser + " hhhh");
	 	     		 			System.out.println(Connexioncontroller.MailUser+"n");
	 	     		 			//System.out.println(heure.getSelectionModel().getSelectedItem()+minute.getSelectionModel().getSelectedItem());
	 	        	
			 			if(res1.next()==true){
	 	        		System.out.println(res1.getString("id_user"));
	 	        	PreparedStatement st2=con.prepareStatement("select * from demandeclient where id_user='"+res1.getInt("id_user")+"'");
	 	        	ResultSet res2=st2.executeQuery();
		 	        	if(res2.next()==true) {
				    		 System.out.println(modi.recup�rer());
			 	        
			 	        	Alert alert = new Alert(Alert.AlertType.INFORMATION);
			 	            alert.setHeaderText(null);
			 	            alert.setContentText("Vous avez d�j� une demande en cours");
			 	            alert.showAndWait();
		 	        	}else {
		 	        		
	 		 				try {
	 		 	        		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
	 				 			PreparedStatement stmt = con.prepareStatement("INSERT INTO demandeclient (id_user, titre, date, heure, etat,motif,date_dem) VALUES (?,?,?,?,?,?,?)");
	 				 			stmt.setInt(1, res1.getInt("id_user"));
	 				 			stmt.setString(2, "Demande de passage de code");
	 				 			stmt.setString(3, date.getValue().toString());
	 				 			stmt.setString(4, heure.getValue()+minute.getValue());
	 				 			stmt.setString(5, "En attente");
	 				 			stmt.setString(6, "");
	 				 			stmt.setString(7, LocalDate.now().toString());
	 				 			stmt.executeUpdate();
	 				 			
	 				 				Alert alert = new Alert(Alert.AlertType.INFORMATION);
		 			 	            alert.setHeaderText(null);
		 			 	            alert.setContentText("Votre demande a �t� effectu�");
		 			 	            alert.showAndWait();
	 				 			
	 				 			
	 				 			Clearfield();
	 				 			} catch (SQLException ex) {
	 				 				        	ex.printStackTrace();
	 				 			}
	 		 			}
			 			}
	 	        	
			 	 	 			
			 			    	
		        	}catch(Exception e1) {
		        		e1.printStackTrace();
		        	}
	    }
	    
	    @FXML
	     void choixoption() {
	    	list=afficher();
	    	heure.setItems(list);
	    }
	    @FXML
	     void choixoption1() {
	    	list1=afficher1();
	    	minute.setItems(list1);
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"08h","09h","10h","11h","12h","13h","14h","15h","16h","17h","18h"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

	@Override
	public ObservableList<String> afficher1() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"00","05","10","15","20","25","30","35","40","45","50","55"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

}
