package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mysql.cj.xdevapi.Statement;

import Bdconnect.Mysqlconnect;
import admincontrollers.Modifvehicontroller;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Offrepanelcontroller implements Initializable{
	
	 @FXML
	    private Label a_intro;

	    @FXML
	    private Label a_tarif;

	    @FXML
	    private Label b_intro;

	    @FXML
	    private Label b_tarif;

	    @FXML
	    private Label c_intro;

	    @FXML
	    private Label c_tarif;

	    @FXML
	    private Label d_intro;

	    @FXML
	    private Label d_tarif;

	    @FXML
	    void a_desc(MouseEvent event) throws SQLException, IOException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre A'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/interfaces/Description.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Descriptioncontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS MOTOS :CATEGORIE A");
			         modi.setdesc(res.getString("description"));
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			         
			}
	    }

	    @FXML
	    void b_desc(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre B'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/interfaces/Description.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Descriptioncontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS VOITURE: CATEGORIE B");
			         modi.setdesc(res.getString("description"));
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			         
			}
	    }

	    @FXML
	    void c_desc(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre C'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/interfaces/Description.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Descriptioncontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS POIDS LOURD DE CATEGORIE C");
			         modi.setdesc(res.getString("description"));
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			         
			}
	    }

	    @FXML
	    void d_desc(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre D'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/interfaces/Description.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Descriptioncontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS POIDS LOURD DE CATEGORIE D");
			         modi.setdesc(res.getString("description"));
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			         
			}
	    }

	    @FXML
	    void permisA(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre A'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/Autres/Paiement.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Paiementcontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS MOTOS :CATEGORIE A");
			         modi.setsomme(res.getString("tarif"));
			         modi.setpermis("A");
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			         
			}
	    }

	    @FXML
	    void permisB(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre B'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/Autres/Paiement.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Paiementcontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS VOITURE: CATEGORIE B");
			         modi.setsomme(res.getString("tarif"));
			         modi.setpermis("B");
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			}
	    }

	    @FXML
	    void permisC(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre C'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/Autres/Paiement.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Paiementcontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS POIDS LOURD DE CATEGORIE D");
			         modi.setsomme(res.getString("tarif"));
			         modi.setpermis("C");
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			}
	    }

	    @FXML
	    void permisD(MouseEvent event) throws SQLException {
	    	Connection con=Mysqlconnect.ConnectDb();
			PreparedStatement st=con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre D'");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				  FXMLLoader loader = new FXMLLoader ();
			         loader.setLocation(getClass().getResource("/Autres/Paiement.fxml"));
			         try {
			             loader.load();
			         } catch (IOException ex) {
			             //Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
			         }
			         
			         Paiementcontroller modi=loader.getController();
			       //  modi.setUpdate(true);
			         modi.setTitre("LES PERMIS POIDS LOURD DE CATEGORIE D");
			         modi.setsomme(res.getString("tarif"));
			         modi.setpermis("D");
			         Parent parent = loader.getRoot();
			         Stage stage = new Stage();
			         stage.setScene(new Scene(parent));
			         stage.initStyle(StageStyle.UTILITY);
			         stage.show();
			}
	    }
	    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		PreparedStatement st,st1,st2,st3;
		try {
			st = con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre A'");
			st1 = con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre B'");
			st2= con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre C'");
			st3 = con.prepareStatement("SELECT * FROM offre WHERE nom_offre='offre D'");
			ResultSet res=st.executeQuery(); 
			ResultSet res1=st1.executeQuery(); 
			ResultSet res2=st2.executeQuery(); 
			ResultSet res3=st3.executeQuery(); 
			while(res.next() && res1.next() && res2.next() && res3.next()) {
				a_tarif.setText(res.getString("tarif")+"$");
				b_tarif.setText(res1.getString("tarif")+"$");
				c_tarif.setText(res2.getString("tarif")+"$");
				d_tarif.setText(res3.getString("tarif")+"$");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
