package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Motdepasseoubliecontroller implements Initializable{
	@FXML
    private Label annuler;

    @FXML
    private Label envoyer;

    @FXML
    private TextField mail;
    
    public void send(String to){
    	System.out.println("Mail en cours d'envoi");
        Properties props = new Properties();
        props.setProperty("mail.smtp.host", "localhost");
        props.setProperty("mail.smtp.port", "3306");
       // props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.setProperty("mail.smtp.auth", "true");
       // props.setProperty("mail.smtp.prot", "3306");
       // props.put("mail.smtp.starttls.enable", "true"); //TLS
        final String account="driverschool94@gmail.com";
        final String passwd="Driverschool@294";
        Session s = Session.getInstance(props,
        new javax.mail.Authenticator() {
        protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(account, passwd);
        }
        });
        
        //Session
       
        /*try {
            Message message = new MimeMessage(s);
            message.setFrom(new InternetAddress(account));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("MAIL SUBJECT !");
            message.setText("MAIL BODY !");
            Transport.send(message);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }*/
				Message mes=PrepareMessage(s,account,to);
				
				try {
					Transport.send(mes);
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
	 	            alert.setHeaderText(null);
	 	            alert.setContentText("Veuillez consulter votre bo�te mail pour r�cup�rer votre mot de passe");
	 	            alert.showAndWait();
					
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    }
    public Message PrepareMessage(Session s,String a,String r){
        String pass="";
        
		try {
			PreparedStatement st;
			Connection con=Mysqlconnect.ConnectDb();
			st = con.prepareStatement("SELECT * FROM utilisateurs WHERE mail_user='"+mail.getText()+"'");
			 ResultSet res=st.executeQuery(); 
	        	if(res.next()) {
	        	pass=res.getString("mot_passe");
	        	}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
       
        String text="Votre mot de passe est :"+pass+"";
        	String titre="Recup�ration de votre mot de passe";
        	
        	Message m=new MimeMessage(s);
        	
        	try {
				m.setFrom(new InternetAddress("a"));
				m.setRecipient(Message.RecipientType.TO, new InternetAddress(r));
				m.setSubject(titre);
				String htmlcode="<h1> "+text+"</h1> <h2><b> </b></h2>";
				m.setContent(htmlcode, "text/html");
				return m;
        	}
			 catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return m;
      }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		envoyer.setOnMouseClicked(event->{
			String email;
			try {
				Connection con=Mysqlconnect.ConnectDb();
				PreparedStatement st=con.prepareStatement("SELECT * FROM utilisateurs WHERE mail_user='"+mail.getText()+"'");
				ResultSet res=st.executeQuery(); 
				if(res.next()==true) {
					email=res.getString("mail_user");
					send(email);
				}else {
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
	 	            alert.setHeaderText(null);
	 	            alert.setContentText("Veuillez entrer une adresse mail valide");
	 	            alert.showAndWait();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			send(mail.getText());
		});
	}

}
