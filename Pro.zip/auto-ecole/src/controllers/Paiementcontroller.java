package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Paiementcontroller implements Initializable{

	@FXML
    private TextField montant;

    @FXML
    private AnchorPane paie;

    @FXML
    private Label restant;

    @FXML
    private Button retour;

    @FXML
    private Label somme;

    @FXML
    private Label titre;

    @FXML
    private Label tot;

    @FXML
    private Button valid;

    @FXML
    private Button validate;

    @FXML
    private TextField code;

    @FXML
    private DatePicker date;

    @FXML
    private TextField name;

    @FXML
    private TextField number;
    
    public static String perm;
    
    @FXML
    private Label paye1;

    @FXML
    private Label rap;
    @FXML
    void confirm(MouseEvent event) {

    }
    
    void setsomme(String a) {
    	tot.setText(a);
    }

    void setTitre(String b) {
    	titre.setText(b);
    }
    void setRap(String a) {
    	rap.setText(a);
    }
    void setpermis(String b) {
    	perm=b;
    }
    void setpaye(String b) {
    	paye1.setText(b);
    }
    @FXML
    void valide(MouseEvent event) {
    	float a=Float.parseFloat(tot.getText())-(Float.parseFloat(montant.getText())+Float.parseFloat(paye1.getText()));
    	restant.setText(Float.toString(a));
    	somme.setText(montant.getText());
    	
    }

    public static boolean checkNom(String postCode) {
   	 if (postCode.charAt(0)>'Z' || postCode.charAt(0)<'A') {
	            return false;
   	 }
           for (int i = 0; i < postCode.length(); i++) {
               if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
                   return false;
                
           }
       }
       return true;
   }
    
    public static boolean checkNumber(String postCode) {
    	int lengthPost=16;
   	 if (postCode.length()!=lengthPost) {
	            return false;
   	 }
           for (int i = 0; i < postCode.length(); i++) {
               if (i >= 0 && Character.isLetter(postCode.charAt(i))) {
                   return false;
                
           }
       }
       return true;
   }
    public static boolean checkcode(String postCode) {
    	int lengthPost=3;
   	 if (postCode.length()!=lengthPost) {
	            return false;
   	 }else {
   		 
   	      for (int i = 0; i < postCode.length(); i++) {
               if (i >= 0 && Character.isLetter(postCode.charAt(i))) {
                   return false;
            }     
       }
   	}
     
       return true;
   }
	    @FXML
	    void annuler(MouseEvent event) {
	    	 Stage stage = (Stage)paie.getScene().getWindow();
	         stage.close();
	    }

	    private static void showAlert(Alert.AlertType alertType, Window owner, String message, String title) {
	        Alert alert = new Alert(alertType);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(message);
	        alert.initOwner(owner);
	        alert.show();
	    }
	    @FXML
	    void valider(MouseEvent event) {
	    	Window owner = valid.getScene().getWindow();

	    	if (name.getText().isEmpty() ||  number.getText().isEmpty() ||  code.getText().isEmpty()|| date.getValue()==null) {
 	            Alert alert = new Alert(Alert.AlertType.ERROR);
 	            alert.setHeaderText(null);
 	            alert.setContentText("Veuillez remplir tous les champs");
 	            alert.showAndWait();

 	        } else
	             if(checkNom(name.getText())==false){
	             showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un nom valide", "Erreur");
	         }else 
	        	 if(checkNumber(number.getText())==false){
	             showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un num�ro valide", "Erreur");
	         } else 
	        	 if(checkcode(code.getText())==false){
	             showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un code valide", "Erreur");
	         }else 
	        	 if(date.getValue().isBefore(LocalDate.now())){
	             showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer une date valide", "Erreur");
	         }else {
	        	 try {
	         		Connection con=Mysqlconnect.ConnectDb();
	         		String val1=somme.getText();
	         		con=Mysqlconnect.ConnectDb();
 	        		FXMLLoader loader = new FXMLLoader ();
 	               loader.setLocation(getClass().getResource("/interfaces/Conneion.fxml"));
 	               try {
 	                   loader.load();
 	               } catch (IOException ex) {
 	                   ex.printStackTrace();
 	               }
 	               
 	     	        	 Connexioncontroller modi=loader.getController();
 	     	        	//int i=1;
 	     	        	
 	     	    		 PreparedStatement st=con.prepareStatement("select * from utilisateurs where mail_user='"+modi.MailUser+"'");
 	     		 			ResultSet res=st.executeQuery(); 
 	     		 		//System.out.println(modi.MailUser + " hhhh");
 	     		 			System.out.println(modi.recup�rer()+"n");
 	     		 			//System.out.println(heure.getSelectionModel().getSelectedItem()+minute.getSelectionModel().getSelectedItem());
 	        	
		 			while(res.next()){
		 				if(Float.parseFloat(restant.getText())==0.0) {
		 					Float x=Float.parseFloat(res.getString("montantpay�"))+Float.parseFloat(montant.getText());
		 					String sql="Update utilisateurs set montantpay�='"+Float.toString(x)+"' , statut='Termin�' where id_user='"+res.getString("id_user")+"'";
			         		PreparedStatement st1=con.prepareStatement(sql);
			         		st1.execute();
			         		JOptionPane.showMessageDialog(null, "Modifications effectu�es avec succ�s");
			     	 			}else
			     	 				if(Float.parseFloat(restant.getText())>0.0) {
			     	 					Float x=Float.parseFloat(res.getString("montantpay�"))+Float.parseFloat(montant.getText());
					 					String sql="Update utilisateurs set montantpay�='"+Float.toString(x)+"' , statut='En cours', permis='"+perm+"' where id_user='"+res.getString("id_user")+"'";
						         		PreparedStatement st1=con.prepareStatement(sql);
						         		st1.execute();
						         		JOptionPane.showMessageDialog(null, "Paiement effectu� avec succ�s");
						         		 
						     	 			}
		 				}
	     			}catch(Exception e) {
	         		e.printStackTrace();
	         	}	
	         	
	         }
	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
