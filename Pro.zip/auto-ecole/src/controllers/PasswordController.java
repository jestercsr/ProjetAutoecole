package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PasswordController implements Initializable{
	Connection cn=null;
	Statement stmt;
	@FXML
    private TextField new_conf;

    @FXML
    private TextField newp;

    @FXML
    private TextField old;

    @FXML
    void annuler() {

    }

    @FXML
    void validate() throws SQLException {
    	cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
		
    	try {
    				stmt= cn.createStatement();
					ResultSet res=null;
					res=stmt.executeQuery("Select * from utilisateurs where id_user='1'"); 
					while ( res.next() )
					{
						if(old.getText()==res.getString(10)) {
								if(newp.getText()==new_conf.getText()) {
									PreparedStatement stmt = cn.prepareStatement("UPDATE utilisateurs SET mot_passe=?");
									stmt.setString(0, newp.getText());
								}else {
									Alert errorAlert = new Alert(AlertType.ERROR);
									errorAlert.setHeaderText("Input not valid");
									errorAlert.setContentText("Les deux mots de passe sont incompatibles");
									errorAlert.showAndWait();}
						}else {
							Alert errorAlert = new Alert(AlertType.ERROR);
							errorAlert.setHeaderText("Input not valid");
							errorAlert.setContentText("L'ancien mot de passe est incorrect");
							errorAlert.showAndWait();
						}

					}
					
				}catch (Exception e1) {
					e1.printStackTrace();	    
					
				}
			
			
		
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	

}
