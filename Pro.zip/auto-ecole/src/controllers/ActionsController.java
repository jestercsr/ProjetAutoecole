package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.AnchorPane;

public class ActionsController implements Initializable,Liste{
	
	   @FXML
	    private ChoiceBox<String> choixac;

	    @FXML
	    private AnchorPane next;
	    
	    ObservableList<String> list;
	    
	   void monchoix(ActionEvent event) {
	    	if(choixac.getValue()=="Consulter ma progression") {
	    		try {
	         	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Progression.fxml"));
	         		 next.getChildren().removeAll();
	         		 next.getChildren().setAll(parent);
	         		} catch (IOException e) {
	         			
	         			e.printStackTrace();
	         		}
	    	}else if(choixac.getValue()=="Faire une demande de passage de code") {
	    		try {
	         	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/PassageCode.fxml"));
	         		 next.getChildren().removeAll();
	         		 next.getChildren().setAll(parent);
	         		} catch (IOException e) {
	         			
	         			e.printStackTrace();
	         		}
	    	}else {
	    		try {
	         	   	 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Reserconduite.fxml"));
	         		 next.getChildren().removeAll();
	         		 next.getChildren().setAll(parent);
	         		} catch (IOException e) {
	         			
	         			e.printStackTrace();
	         		}
	    	}
	    	
	    }
	   
	    @FXML
	     void choixoption() {
	    	list=afficher();
	    	choixac.setItems(list);
	    	choixac.setOnAction(this::monchoix);
	    }
	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Consulter ma progression","Faire une demande de passage de code","R�server des s�ances de conduite"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
