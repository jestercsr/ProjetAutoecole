package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

public class LocalisationController implements Initializable,Liste{

    @FXML
    private ListView<String> programme;
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
	try {
			PreparedStatement st=con.prepareStatement("SELECT * FROM seances WHERE date_eve=DATE(NOW()) ORDER BY seances.heure_debut ASC");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				listprog.add(res.getString("heure_debut")+"-"+ 
						res.getString("heure_fin")+" : "+res.getString("nom_eve")
							+" avec M. "+
							res.getString("id_emp"));
				}
			programme.getItems().addAll(listprog);
		}catch(Exception e) {
			System.out.println();
		}
	return listprog;
	}

}
