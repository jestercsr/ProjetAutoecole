package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Bdconnect.Mysqlconnect;
import Interface.Clearf;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Inscriptioncontroller implements Initializable,Clearf{
	
	Connection con;
	 @FXML
	    private CheckBox affiche;

	    @FXML
	    private TextField comp_adre;

	    @FXML
	    private PasswordField conf_mdp;

	    @FXML
	    private TextField mail;

	    @FXML
	    private PasswordField mdp;

	    @FXML
	    private TextField nom;
	    
	    @FXML
	    private DatePicker dt;

	    @FXML
	    private TextField nom_rue;

	    @FXML
	    private TextField num;

	    @FXML
	    private TextField num_rue;

	    @FXML
	    private TextField postal;

	    @FXML
	    private TextField prenom;

	    @FXML
	    private TextField ville;
	    
	    @FXML
	    private Button inscrip;
	    
	    @FXML
	    private Button connexion;
	    
	    @FXML
	    private TextField conf_mdp1;

	    @FXML
	    private TextField mdp1;

	    @FXML
	    void annuler(MouseEvent event) {
	    	clearFields();
	    }
	    @FXML
	    void connect(MouseEvent event) throws IOException {
	    	 Parent root = FXMLLoader.load(getClass().getResource("/interfaces/Conneion.fxml"));
	            Scene scene = new Scene(root);
	            Stage appStage = (Stage) connexion.getScene().getWindow();
	            appStage.setScene(scene);
	            appStage.show();
	    }
	    
	    public static final Pattern valid_email =
	            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

	    public static final Pattern valid_passwd =
	            Pattern.compile("^[A-Z0-9_]{12,25}$", Pattern.CASE_INSENSITIVE);

	   

	    public static boolean validate(String emailStr) {
	        Matcher matcher = valid_email.matcher(emailStr);
	        return matcher.find();
	    }
	    
	    public static boolean checkPostcode(String postCode) {
	    	int lengthPost=5;
	        if (postCode.length() != lengthPost || postCode.charAt(0) == '0') {
	            return false;
	        }
	        if (postCode.length() == lengthPost) {
	            for (int i = 0; i < postCode.length(); i++) {
	                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
	                    return true;
	                }
	            }
	        }
	        return true;
	    }
	        
	        public static boolean checkTel(String postCode) {
		    	int lengthPost=10;
		        if (postCode.length() != lengthPost || postCode.charAt(0) != '0') {
		            return false;
		        }
		        if (postCode.length() == lengthPost) {
		            for (int i = 0; i < postCode.length(); i++) {
		                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
		                    return true;
		                }
		            }
		        }
		        return true;
	    }
	    public static boolean checkNumrue(String postCode) {
	    	int lengthPost=3;
	        if (postCode.length() > lengthPost) {
	            return false;
	        }
	        if (postCode.length() <=lengthPost) {
	            for (int i = 0; i < postCode.length(); i++) {
	                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
	                    return true;
	                }
	            }
	        }
	        return true;
	    }
	    public static boolean checkNom(String postCode) {
	    	 if (postCode.charAt(0)>'Z' || postCode.charAt(0)<'A') {
		            return false;
	    	 }
	            for (int i = 0; i < postCode.length(); i++) {
	                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
	                    return false;
	                 
	            }
	        }
	        return true;
	    }
	    public static boolean checkNomVille(String postCode) {
	    	//int lengthPost=3;
	            for (int i = 0; i < postCode.length(); i++) {
	                if (i >= 0 && Character.isDigit(postCode.charAt(i))) {
	                    return false;
	                }
	            }
	        return true;
	    }
	    @FXML
	    void viewpass(ActionEvent e) {
	    	if (affiche.isSelected()) {
	            mdp1.setText(mdp.getText());
	            mdp1.setVisible(true);
	            mdp.setVisible(false);
	            conf_mdp1.setText(conf_mdp.getText());
	            conf_mdp1.setVisible(true);
	            conf_mdp.setVisible(false);
	            return;
	        }
	        mdp.setText(mdp1.getText());
	        mdp.setVisible(true);
	        mdp1.setVisible(false);
	        conf_mdp.setText(conf_mdp1.getText());
	        conf_mdp.setVisible(true);
	        conf_mdp1.setVisible(false);
	    }
	    public static boolean validatePsw(String passwdStr) {
	        Matcher matcher = valid_passwd.matcher(passwdStr);
	        return matcher.find();
	    }

	    private static void showAlert(Alert.AlertType alertType, Window owner, String message, String title) {
	        Alert alert = new Alert(alertType);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(message);
	        alert.initOwner(owner);
	        alert.show();
	    }
	    public boolean checkProfile(String profile)
	    {
	        PreparedStatement ps;
	        ResultSet rs;
	        boolean checkProfile = false;
	        String query =  "SELECT * FROM utilisateurs WHERE mail_user = ?";


	        try {
	            ps = Mysqlconnect.ConnectDb().prepareStatement(query);
	            ps.setString(1, profile);

	            rs = ps.executeQuery();

	            if(rs.next())
	            {
	                checkProfile = true;
	            }
	        } catch (SQLException ex) {
	         //   Logger.getLogger(Mysqlconnect.class.getName()).log(Level.SEVERE, null, ex);
	        	ex.printStackTrace();
	        }
	        return checkProfile;
	    }
	    public static void infoBox(String infoMessage, String headerText, String title) {
	        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
	        alert.setContentText(infoMessage);
	        alert.setTitle(title);
	        alert.setHeaderText(headerText);
	        alert.showAndWait();
	    }

	    @FXML
	    void inscritp(MouseEvent event) {
	    	Window owner = inscrip.getScene().getWindow();

	    	if (nom.getText().isEmpty() ||  prenom.getText().isEmpty() || mail.getText().isEmpty() || num.getText().isEmpty() || nom_rue.getText().isEmpty() ||num_rue.getText().isEmpty() ||ville.getText().isEmpty()|| postal.getText().isEmpty()|| comp_adre.getText().isEmpty()|| mdp.getText().isEmpty()|| conf_mdp.getText().isEmpty()) {
 	            Alert alert = new Alert(Alert.AlertType.ERROR);
 	            alert.setHeaderText(null);
 	            alert.setContentText("Veuillez remplir tous les champs");
 	            alert.showAndWait();

 	        } else
	             if(mail.getText().isEmpty()){
	             showAlert(Alert.AlertType.CONFIRMATION, owner, "Please enter an email address", "Erreur");
	         }

	         else if(!validate(mail.getText())){
	             showAlert(Alert.AlertType.CONFIRMATION, owner, "Please enter a valid email address", "Erreur");
	         }

	         else 
	        	  if(checkNumrue(num_rue.getText())==false){
	        	 			showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un num�ro de rue valide", "Erreur");
	        	 		}else 
	        	 			if(checkPostcode(postal.getText())==false){
	        	 				showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un code postal valide", "Erreur");
	        	 			}else 
	        	 				if(checkNomVille(ville.getText())==false){
	        	 					showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un nom de ville valide", "Erreur");
	        	 				}else 
	        	 					if(checkTel(num.getText())==false){
	        	 						showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer un num�ro de t�l�phone valide", "Erreur");
	        	 					}else 
	        	 						if(checkNom(nom.getText())==false){
	        	 							showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez vous assurer que votre nom commence par une lettre majuscule", "Erreur");
	        	 						}else
	        	 							if(checkNom(prenom.getText())==false){
	        	 								showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez vous assurer que votre pr�nom commence par une lettre majuscule", "Erreur");
	        	 							}else 
	        	 								if(!(mdp.getText().equals(conf_mdp.getText()))){
	        	 									showAlert(Alert.AlertType.CONFIRMATION, owner, "Veuillez entrer des mots de passe identiques", "Erreur");
	        	 								}else
	        	 									if(checkProfile(mail.getText())==true) {
	        	 										showAlert(Alert.AlertType.CONFIRMATION, owner,"Ce Utilisateur existe d�j�. Veuillez vous connecter", "Erreur");
	        	 									}else
	        	 	 									if(LocalDate.now().getYear()-dt.getValue().getYear()<16) {
	        	 	 										showAlert(Alert.AlertType.CONFIRMATION, owner,"Le client doit obligatoirement avoir au moins 16ans", "Erreur");
	        	 	 									}else{
	        	 										String sql_register = "INSERT INTO `utilisateurs`(`nom_user`, `prenom_user`, `date_nais`, `mail_user`, `num_user`, `num_rue`, `nom_rue`, `code_postal`, `nom_ville`, `compl�ment_adress`, `mot_passe`, `permis`, `statut`, `montantpay�`, `tuteur`,date_insc) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	             try {
	               PreparedStatement  stmt = Mysqlconnect.ConnectDb().prepareStatement(sql_register);
	               		//stmt.setInt(1, 1);
	                 	stmt.setString(1, nom.getText());
				 		stmt.setString(2, prenom.getText());
				 		stmt.setString(3, dt.getValue().toString());
				 		stmt.setString(4, mail.getText());
				 		stmt.setString(5, num.getText());
				 		stmt.setInt(6, Integer.valueOf(num_rue.getText()));
				 		stmt.setString(7, nom_rue.getText());
				 		stmt.setInt(8, Integer.valueOf(postal.getText()));
				 		stmt.setString(9, ville.getText());
				 		stmt.setString(10, comp_adre.getText());
				 		stmt.setString(11, mdp.getText());
				 		stmt.setString(12, "");
				 		stmt.setString(13, "En attente");
				 		stmt.setFloat(14, 0);
				 		stmt.setInt(15, 0);
				 		stmt.setString(16, LocalDate.now().toString());
				 		stmt.executeUpdate();
				 		infoBox("New User Add", null, "Welcome " + mail.getText());
	     

	             } catch (SQLException ex) {
	            	// infoBox("New User Add Error", null,"");
	            	 ex.printStackTrace();
	             }
	         }
			 			    	
	    }
	  

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		//viewpass();
	}

	@Override
	public void clearFields() {
		// TODO Auto-generated method stub
		nom.clear();
		prenom.clear();
		mail.clear();
		num.clear();
		num_rue.clear();
		nom_rue.clear();
		ville.clear();
		postal.clear();
		comp_adre.clear();
		mdp.clear();
		conf_mdp.clear();
	}

}
