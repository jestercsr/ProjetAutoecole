package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class AccueilClientController implements Initializable{
   
	@FXML
    private ImageView compte;

    @FXML
    private Label nom;
    @FXML
    private AnchorPane suivant;
    
    @FXML
    private ImageView notif;

    @FXML
    private Label rouge;
    
    @FXML
    private ListView<String> programme;
 
    public ObservableList<String> liste() {
    	Connection con=Mysqlconnect.ConnectDb();
    	ObservableList<String> listprog=FXCollections.observableArrayList();
	try {
			PreparedStatement st=con.prepareStatement("SELECT * FROM seances WHERE date_eve=DATE(NOW()) ORDER BY seances.heure_debut ASC");
			ResultSet res=st.executeQuery(); 
			while(res.next()) {
				listprog.add(res.getString("heure_debut")+"-"+ 
						res.getString("heure_fin")+" : "+res.getString("nom_eve")
							+" avec M. "+
							res.getString("id_emp"));
				}
			programme.getItems().addAll(listprog);
		}catch(Exception e) {
			System.out.println();
		}
	return listprog;
    }
    @FXML
    void notifications()
    {
    	try {
     		Connection con=Mysqlconnect.ConnectDb();
	     		con=Mysqlconnect.ConnectDb();
	     		FXMLLoader loader = new FXMLLoader ();
	            loader.setLocation(getClass().getResource("/interfaces/Conneion.fxml"));
	            try {
	                loader.load();
	            } catch (IOException ex) {
	                ex.printStackTrace();
	            }
	            
	  	        	 Connexioncontroller modi=loader.getController();
	  	        	//int i=1;
	  	        	System.out.println(Connexioncontroller.MailUser);
	  	    		 PreparedStatement st=con.prepareStatement("select * from utilisateurs where mail_user='"+Connexioncontroller.MailUser+"'");
	  		 			ResultSet res=st.executeQuery(); 
	  		 			while(res.next()) {
	  		 				PreparedStatement st1=con.prepareStatement("SELECT * FROM demandeclient where id_user='"+res.getString("id_user")+"' and etat='Non vu' and etat!='En attente'");
	  		 				ResultSet res1=st1.executeQuery(); 
		  		 			if(res1.next()) {
		  		 					rouge.setVisible(false);
		  		 			}else {
		  		 				rouge.setVisible(true);
		  		 			}
	  		 			}}catch(Exception e) {
  		 	   e.printStackTrace();
  		 	}
		}
    	
    	
    @FXML
    void accueil(MouseEvent event) {
    	try {
    		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Localisation.fxml"));
      		 suivant.getChildren().removeAll();
      		 suivant.getChildren().setAll(parent);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }

    @FXML
    void actions(MouseEvent event) {
    	try {
   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Actions.fxml"));
     		 suivant.getChildren().removeAll();
     		 suivant.getChildren().setAll(parent);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }

    @FXML
    void contact(MouseEvent event) {
    	try {
   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/usersmoni.fxml"));
     		 suivant.getChildren().removeAll();
     		 suivant.getChildren().setAll(parent);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }

    @FXML
    void offres(MouseEvent event) {
    	try {
     		Connection con=Mysqlconnect.ConnectDb();
     		con=Mysqlconnect.ConnectDb();
     		FXMLLoader loader = new FXMLLoader ();
            loader.setLocation(getClass().getResource("/interfaces/Conneion.fxml"));
            try {
                loader.load();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
  	        	 Connexioncontroller modi=loader.getController();
  	        	//int i=1;
  	        	
  	    		 PreparedStatement st=con.prepareStatement("select * from utilisateurs where mail_user='"+modi.MailUser+"'");
  		 			ResultSet res=st.executeQuery(); 
  		 			while(res.next()) {
  		 				nom.setText(res.getString("nom_user")+" "+res.getString("prenom_user"));
  		 				if(!res.getString("permis").equals("")) {
  		 					try {
  		  		 		   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Offrepanel2.fxml"));
  		  		 		     		 suivant.getChildren().removeAll();
  		  		 		     		 suivant.getChildren().setAll(parent);
  		  		 		    	}catch(Exception e) {
  		  		 		    		e.printStackTrace();
  		  		 		    	}
  		 				}else {
  		 				try {
  		 		   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/Offrepanel.fxml"));
  		 		     		 suivant.getChildren().removeAll();
  		 		     		 suivant.getChildren().setAll(parent);
  		 		    	}catch(Exception e) {
  		 		    		e.printStackTrace();
  		 		    	}
  		 				}
  		 			}}catch(Exception e) {
  		 	    		e.printStackTrace();
  		 	    	}
    	
    }

    @FXML
    void plannings(MouseEvent event) {
    	try {
   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/admininterfaces/usersmoni.fxml"));
     		 suivant.getChildren().removeAll();
     		 suivant.getChildren().setAll(parent);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    void Name(String a) {
    	nom.setText(a);
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stud
		notifications();
		compte.setOnMouseClicked(event->{
			try {
		   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/UserPanel.fxml"));
		     		 suivant.getChildren().removeAll();
		     		 suivant.getChildren().setAll(parent);
		    	}catch(Exception e) {
		    		e.printStackTrace();
		   		}
		});
		nom.setOnMouseClicked(event->{
			try {
		   		 AnchorPane parent=FXMLLoader.load(getClass().getResource("/interfaces/UserPanel.fxml"));
		     		 suivant.getChildren().removeAll();
		     		 suivant.getChildren().setAll(parent);
		    	}catch(Exception e) {
		    		e.printStackTrace();
		   		}
		});
	notif.setOnMouseClicked(event->{
		rouge.setVisible(false);
	});
		try {
     		Connection con=Mysqlconnect.ConnectDb();
	     		con=Mysqlconnect.ConnectDb();
	     		FXMLLoader loader = new FXMLLoader ();
	            loader.setLocation(getClass().getResource("/interfaces/Conneion.fxml"));
	            try {
	                loader.load();
	            } catch (IOException ex) {
	                ex.printStackTrace();
	            }
	            
	  	        	 Connexioncontroller modi=loader.getController();
	  	        	//int i=1;
	  	        	System.out.println(Connexioncontroller.MailUser);
	  	    		 PreparedStatement st=con.prepareStatement("select * from utilisateurs where mail_user='"+Connexioncontroller.MailUser+"'");
	  		 			ResultSet res=st.executeQuery(); 
	  		 			while(res.next()) {
	  		 				nom.setText(res.getString("nom_user")+" "+res.getString("prenom_user"));
  		 			}
  		 	}catch(Exception e) {
  		 	   e.printStackTrace();
  		 	}
		}

		

}
