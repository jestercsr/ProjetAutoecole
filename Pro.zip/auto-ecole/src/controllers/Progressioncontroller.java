package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import Interface.Liste;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Progressioncontroller implements Initializable,Liste{
	

    @FXML
    private ChoiceBox<String> choixac;
    
    ObservableList<String> list;
	   
	    @FXML
	     void choixoption() {
	    	list=afficher();
	    	choixac.setItems(list);
	    	//choixac.setOnAction(this::monchoix);
	    }
	@Override
	public ObservableList<String> afficher() {
		// TODO Auto-generated method stub
		Connection con=Mysqlconnect.ConnectDb();
		ObservableList<String> list=FXCollections.observableArrayList();
		 String [] listi={"Progression session de code","Progression heures de conduite"};
		 for(int i=0;i<listi.length;i++) {
			 try {
	    			list.add(listi[i]);
	        		}catch(Exception e) {
	        			System.out.println();
	        		}
		 }
		
		return list;
	}
    @FXML
    void annuler(MouseEvent event) {

    }

    @FXML
    void valider(MouseEvent event) {
    	if(choixac.getValue()=="Consulter ma progression") {
    		try {
    		 	Parent parent=FXMLLoader.load(getClass().getResource("/admininterfaces/ajoutvehicule.fxml"));
	      		Scene scene=new Scene(parent);
	      		Stage stage=new Stage();
	      		stage.setScene(scene);
	      		stage.initStyle(StageStyle.UTILITY);
	      		stage.show();
         		} catch (IOException e) {
         			e.printStackTrace();
         		}
    	}else {
    		try {
    		 	Parent parent=FXMLLoader.load(getClass().getResource("/admininterfaces/ajoutvehicule.fxml"));
	      		Scene scene=new Scene(parent);
	      		Stage stage=new Stage();
	      		stage.setScene(scene);
	      		stage.initStyle(StageStyle.UTILITY);
	      		stage.show();
         		} catch (IOException e) {
         			
         			e.printStackTrace();
         		}
    	}
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
