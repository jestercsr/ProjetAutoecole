package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Bdconnect.Mysqlconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Connexioncontroller implements Initializable{

	@FXML
    private TextField tfid;

    @FXML
    private PasswordField pf;

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnReg;

    @FXML
    private AnchorPane change;
    
    @FXML
    private Label mdpo;
    
    private boolean connect�;
    
    public static String MailUser;

    @FXML
    void onClickReg(MouseEvent event) throws IOException {
    	//String fileName="Inscription";
    	 Parent root = FXMLLoader.load(getClass().getResource("/interfaces/Inscription.fxml"));
         Scene scene = new Scene(root);
         Stage appStage = (Stage) btnReg.getScene().getWindow();
         appStage.setScene(scene);
         appStage.show();
    }


    public boolean checkProfile(String email, String mdp)
    {
       
        return false;
    }
    @FXML
    public void onClickLogin() throws IOException {
        Window owner = btnLogin.getScene().getWindow();

        System.out.println(tfid.getText());
        System.out.println(pf.getText());

        if (tfid.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Please enter your email id",
                    "Form Error!");
        }
        else if (pf.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Please enter a password",
                    "Form Error!");
        }
     //   String emailId = tfid.getText();
      //  String password = pf.getText();


      //  boolean flag = checkProfile(emailId, password);
        PreparedStatement ps;
        ResultSet rs;
        //boolean checkProfile = false;
        String query =  "SELECT * FROM utilisateurs WHERE mail_user = ? and mot_passe = ?";


        try {
            ps = Mysqlconnect.ConnectDb().prepareStatement(query);
            ps.setString(1, tfid.getText());
            ps.setString(2, pf.getText());

            System.out.println(ps);

            rs = ps.executeQuery();

           
           if(rs.next()==true) {
        	   if( rs.getString("etat_compte").equals("Supprim�")) {
           		infoBox("Ce compte a �t� supprim� \nVous ne pouvez plus y avoir acc�s", null, "Erreur");
           	}
           	if(!rs.getString("etat_compte").equals("Supprim�")) {
           		setConnect�(true);
                   infoBox("Login Successful!", null, "Success");
                   Parent root = FXMLLoader.load(getClass().getResource("/interfaces/AccueilClient.fxml"));
                   MailUser = tfid.getText();
                   Scene scene = new Scene(root);
                   Stage appStage = (Stage) btnLogin.getScene().getWindow();
                   appStage.setScene(scene);
                   appStage.show();
           		
           	}
           }
            	else
            if(!rs.next()) {
            	infoBox("Veuillez entrez une adresse e-mail et un mot de passe valide", null, "Erreur");
            }
               
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    public TextField getTfid() {
		return tfid;
	}


	public void setTfid(TextField tfid) {
		this.tfid = tfid;
	}


	public boolean isConnect�() {
		return connect�;
	}


	public void setConnect�(boolean connect�) {
		this.connect� = connect�;
	}


	public String recup�rer() {
		return getTfid().getText();
	}


	


	public PasswordField getPf() {
		return pf;
	}


	public void setPf(PasswordField pf) {
		this.pf = pf;
	}


	public static void infoBox(String infoMessage, String headerText, String title) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }


    private static void showAlert(Alert.AlertType alertType, Window owner, String message, String title) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		recup�rer();
		mdpo.setOnMouseClicked(event->{
			 Parent root;
			try {
				root = FXMLLoader.load(getClass().getResource("/interfaces/Motdepasseoublie.fxml"));
				Scene scene = new Scene(root);
	             Stage appStage = (Stage) btnLogin.getScene().getWindow();
	             appStage.setScene(scene);
	             appStage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             
		});
	}

}
