package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class UserInformationsController implements Initializable{
	
			Connection cn=null;
			PreparedStatement stmt;
	
		// TODO Auto-generated method stub
		  @FXML
		    private Button accepter;

		    @FXML
		    private TextField code_postal;

		    @FXML
		    private TextField comp_adress;

		    @FXML
		    private TextField email;

		    @FXML
		    private TextField nom;

		    @FXML
		    private TextField nom_rue;

		    @FXML
		    private TextField nom_ville;

		    @FXML
		    private TextField num;

		    @FXML
		    private TextField num_rue;

		    @FXML
		    private TextField prenom;

		    @FXML
		    private Button refuse;

		    @FXML
		    void annuler(ActionEvent event) {

		    }

		    @FXML
		    void validate()  {
		    	try {
		    			cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/auto-ecole", "root", "");
			           PreparedStatement stmt = cn.prepareStatement("UPDATE utilisateurs SET nom_user=?,prenom_user=?,mail_user=?,num_user=?,num_rue=?,nom_rue=?,code_postal=?,nom_ville=?,compl�ment_adress=?");
			           	stmt.setString(1, nom.getText());
			            stmt.setString(2, prenom.getText());
			            stmt.setString(3, email.getText());
			            stmt.setString(4, num.getText());
			            stmt.setString(5, num_rue.getText());
			            stmt.setString(6, nom_rue.getText());
			            stmt.setString(7, code_postal.getText());
			            stmt.setString(8, nom_ville.getText());
			            stmt.setString(9, comp_adress.getText());
			            stmt.executeUpdate();
			           // Main.showInformationAlertBox("Informations modifi�es avec succ�s");
			           
			         } catch (Exception e1) {
			            e1.printStackTrace();	        }
		    }

		    public void initialize(URL arg0, ResourceBundle arg1) {
		    	

	}
}


